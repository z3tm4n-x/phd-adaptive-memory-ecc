module composition #(parameter WORD_BITS=19)(input wire mem_clk, cpu_clk, x_clk, command_clk,input wire soft_reset, loss, recover, start_ok,input wire cfg_wr, cfg_commit,input wire [3:0] cfg_address,input wire [31:0] cfg_data,input wire [1:0] app_valid,input wire [3:0] app_kind,input wire [2*WORD_BITS-1:0] app_word,input wire [63:0] app_data,input wire [7:0] app_mask,input wire [127:0] app_id,input wire [1:0] app_reply_ready,input wire cmd_valid,input wire [415:0] cmd_payload,input wire cmd_reply_ready,input wire [15:0] dq_in,input wire err_in);
wire [1:0] app_ready;
wire [1:0] app_reply_valid;
wire [193:0] app_reply_payload;
wire cmd_ready, cmd_reply_valid;
wire [31:0] cmd_reply_payload;
wire ce, oe, we, drive, alias_high;
wire [1:0] byte_enable;
wire [15:0] dq_out;
wire [WORD_BITS-1:0] word_out;
wire busy, pending, flag, done, commit_pulse;
wire [63:0] now, err_count;
wire running, phase_valid, fault;
wire [3:0] queue_state;
executor dut(.*);
endmodule
