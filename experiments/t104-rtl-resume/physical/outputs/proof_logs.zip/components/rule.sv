// T119 two-stage ERR rule. Only COMPLETED history is published in generation.
// Tick timers are conservative T135 counts; ERR pairing uses source timestamps
// so queue jitter cannot hide a close pair. Timestamp units: fast 4-xi edges.
module slow_rule #(
    parameter [33:0] NW=34'd4500045002,NH=34'd9000090002,NR=34'd9015504896,
    parameter [63:0] PAIR_WINDOW=64'd22500225010
)(
    input wire clk,start,event_valid,
    input wire [129:0] event_data,
    input wire history_fault,
    output reg [63:0] processed_generation,
    output wire low,
    output reg [33:0] short_left,long_left,recovery_left,
    output reg healthy,started,
    output reg fault
);
    initial begin
        processed_generation=0;short_left=0;long_left=0;recovery_left=NR;
        healthy=1;started=0;fault=0;
    end
    wire [63:0] event_generation=event_data[129:66];
    wire [63:0] timestamp=event_data[65:2];
    wire event_loss=event_data[1], event_err=event_data[0];
    reg [63:0] last_err=0;
    reg seen_err=0;
    assign low=started && healthy && !history_fault && !fault &&
               short_left==0 && long_left==0 && recovery_left==0 && !event_valid;
    always @(posedge clk) begin
        if(start && !started) begin started<=1; recovery_left<=NR; end
        if(started) begin
            if(short_left!=0) short_left<=short_left-1'b1;
            if(long_left!=0) long_left<=long_left-1'b1;
            if(recovery_left!=0) recovery_left<=recovery_left-1'b1;
        end
        if(history_fault) fault<=1;
        if(event_valid) begin
            // One generation per coalesced event; missing/reordered history
            // quarantines LOW, never assigns the latest fast number blindly.
            if(event_generation!=processed_generation+64'd1) fault<=1;
            processed_generation<=event_generation;
            healthy<=!event_loss;
            if(!event_loss && !healthy) begin
                // Compare with the post-tick hold: equality must renew NR,
                // not silently shorten a recovery by one slow cycle.
                if(recovery_left<=NR) recovery_left<=NR;
            end
            if(event_err) begin
                short_left<=NW;
                if(seen_err && timestamp>=last_err && timestamp-last_err<=PAIR_WINDOW)
                    long_left<=NH;
                last_err<=timestamp; seen_err<=1;
            end
        end
    end

reg seen=0;
always @(posedge clk) begin
 seen<=1;
 assert(!low || (started && healthy && !fault && !history_fault && !event_valid &&
         short_left==0 && long_left==0 && recovery_left==0));
 if(seen) begin
   if($past(event_valid)) assert(processed_generation==$past(event_generation));
   else assert(processed_generation==$past(processed_generation));
   if($past(event_valid && event_err)) begin
     assert(short_left==NW);
     assert(last_err==$past(timestamp));
     if($past(seen_err && timestamp>=last_err && timestamp-last_err<=PAIR_WINDOW)) assert(long_left==NH);
   end
   if($past(event_valid && event_loss)) assert(!healthy);
   if($past(event_valid && !event_loss && !healthy)) assert(recovery_left>=NR);
   if($past(fault || history_fault)) assert(fault);
 end
end

// Full production-width timers, not accelerated simulation parameters.
always @(posedge clk) begin
 assert(short_left<=NW && long_left<=NH && recovery_left<=NR);
 if(seen) begin
  assert(started==($past(started) || $past(start)));
  assert(healthy==($past(event_valid) ? !$past(event_loss) : $past(healthy)));
  if(!$past(event_valid && event_err))
   assert(short_left==($past(started && short_left!=0) ? $past(short_left)-34'd1 : $past(short_left)));
  if(!$past(event_valid && event_err && seen_err && timestamp>=last_err && timestamp-last_err<=PAIR_WINDOW))
   assert(long_left==($past(started && long_left!=0) ? $past(long_left)-34'd1 : $past(long_left)));
  if($past((start && !started) || (event_valid && !event_loss && !healthy))) assert(recovery_left==NR);
  else assert(recovery_left==($past(started && recovery_left!=0) ? $past(recovery_left)-34'd1 : $past(recovery_left)));
  if($past(event_valid && event_generation!=processed_generation+64'd1)) assert(fault);
 end
end

endmodule

module proof(input wire clk,start,event_valid,history_fault,input wire [129:0] event_data); slow_rule dut(.clk(clk),.start(start),.event_valid(event_valid),.history_fault(history_fault),.event_data(event_data)); endmodule