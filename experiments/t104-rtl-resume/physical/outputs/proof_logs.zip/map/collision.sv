// DESIGN SCENARIO, not the proprietary address-to-ECC-word relation.
// W32_seq + H_low: byte=4*word+2*half+lane; x16 address=byte>>1.
module address_map(input wire [18:0] word_index,input wire half,
                   output wire [19:0] address);
    assign address={word_index,1'b0};
endmodule
module proof(input [18:0] w0,w1,input h0,h1,input [19:0] arbitrary_address);
    wire [19:0] a0,a1,a2;
    address_map x(w0,h0,a0),y(w1,h1,a1),z(arbitrary_address[19:1],arbitrary_address[0],a2);
    always @* begin
      assert(a0==2*w0+h0);
      assert(a0!=a1 || (w0==w1 && h0==h1));
      assert(a2==arbitrary_address);
      assert((a0>>1)==w0);
    end
    endmodule
    