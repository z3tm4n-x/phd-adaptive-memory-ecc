// Complete functional two-domain executor, with separate application, history
// and candidate paths. Physical variant exposes the native pin registers.
module integrated_executor #(
    parameter integer WORD_BITS=19,INVERSE=174763,
    parameter [33:0] NW=34'd4500045002,NH=34'd9000090002,NR=34'd9015504896,
    parameter [63:0] PAIR_WINDOW=64'd22500225010
)(
    input wire fast_clk,slow_clk,startup_rst_fast,startup_rst_slow,
    input wire qualified_start,loss_slow,
    input wire [1:0] request_valid,
    output wire [1:0] request_ready,
    input wire [241:0] request_data,
    output wire [1:0] response_valid,input wire [1:0] response_ready,
    output wire [96:0] response_data,
    input wire [15:0] dq_in,input wire err_in,
    output wire [WORD_BITS-1:0] word_out,
    output wire ce,oe,we,drive,alias_high,
    output wire [1:0] byte_enable,output wire [15:0] dq_out,
    output wire running,busy,pending,err_due,release_due,
    output wire grant_debug,app_grant_debug,
    output wire [56:0] grant_data_debug,
    output wire slot_pulse,skip_pulse,freeze_pulse,frozen_execute,
    output wire [63:0] generation,processed_generation,
    output wire rule_low,candidate_permit,
    output wire [33:0] short_left,long_left,recovery_left,
    output wire [31:0] frame_id,
    output wire [1:0] credits_debug,
    output wire pad_ce_n,pad_oe_n,pad_we_n,
    output wire [18:0] prepared_word,
    output wire [1:0] pad_be_n,output wire [15:0] pad_t_n,
    output wire fault
);
    // Slow application admission: two total credits including returned-but-
    // unconsumed replies. CPU wins simultaneous offers; aggregate envelope
    // still applies to first VALID, not to the arbitrarily delayed handshake.
    wire [120:0] req0=request_data[120:0],req1=request_data[241:121];
    wire owner=!request_valid[0];
    wire [120:0] chosen=owner?req1:req0;
    wire legal=(chosen[1:0]==1 || chosen[1:0]==2) && chosen[56:53]!=0 &&
               chosen[20:2]<(20'd1<<WORD_BITS);
    reg [1:0] credits=0;
    wire running_slow;
    wire forward_capacity,id_capacity,id_valid,returned_valid;
    wire [64:0] id_data;
    wire [32:0] returned_data;
    wire can_accept=running_slow && !startup_rst_slow && credits<3 && forward_capacity && id_capacity && legal;
    assign request_ready={can_accept && owner,can_accept && !owner};
    wire capture=|(request_valid & request_ready);
    wire consume=returned_valid && id_valid && response_ready[id_data[64]];
    assign response_valid={returned_valid && id_valid && id_data[64],
                           returned_valid && id_valid && !id_data[64]};
    assign response_data={id_data[63:0],returned_data};
    assign credits_debug=credits;
    always @(posedge slow_clk) begin
        case({capture,consume})
            2'b10:credits<=credits+1'b1;
            2'b01:credits<=credits-1'b1;
            default:credits<=credits;
        endcase
    end

(* anyseq *) reg arbitrary_capacity,arbitrary_return,arbitrary_running;
(* anyseq *) reg [32:0] arbitrary_result;
// Trusted XPM ordered metadata FIFO, implemented here as a circular array.
// Actual bound<=2 makes depth2 equivalent to the production depth16.
reg [64:0] meta[0:1];
reg wp=0,rp=0;
reg [4:0] metadata_count=0;
initial begin meta[0]=0;meta[1]=0;end
assign running_slow=arbitrary_running;
assign forward_capacity=arbitrary_capacity;
assign returned_valid=arbitrary_return;
assign returned_data=arbitrary_result;
assign id_data=meta[rp];
assign id_capacity=metadata_count<16;
assign id_valid=metadata_count!=0;
// Independent shift-register history, including ID/owner and payload.
// A returned payload is the next completed E response by transport+fast
// lemmas. This proof checks that the actual join pairs its matching ID.
reg [121:0] first=0,second=0;
reg [1:0] reference_count=0;
always @(posedge slow_clk) begin
 if(capture) begin meta[wp]<={owner,chosen[120:57]};wp<=!wp;end
 if(consume) rp<=!rp;
 case({capture,consume})
 2'b10:begin
  metadata_count<=metadata_count+1'b1;
  reference_count<=reference_count+1'b1;
  if(reference_count==0) first<={owner,chosen};else second<={owner,chosen};
 end
 2'b01:begin metadata_count<=metadata_count-1'b1;reference_count<=reference_count-1'b1;first<=second;end
 2'b11:begin
  if(reference_count==1) first<={owner,chosen};
  else begin first<=second;second<={owner,chosen};end
 end
 endcase
 assert(credits<=2);
 assert(reference_count==metadata_count && credits==metadata_count);
 assert((wp==rp)==(reference_count!=1));
 if(id_valid) assert(id_data=={first[121],first[120:57]});
 if(|response_valid) begin
  assert(reference_count>0);
  assert(response_data=={first[120:57],arbitrary_result});
  assert(response_valid==(first[121]?2'b10:2'b01));
 end
 assert(!consume || credits>0);
 assert(!capture || (credits<2 && forward_capacity && id_capacity && legal));
 assert(!(request_ready[0] && request_ready[1]));
 if(capture) assert(chosen==(owner?request_data[241:121]:request_data[120:0]));
end
endmodule
