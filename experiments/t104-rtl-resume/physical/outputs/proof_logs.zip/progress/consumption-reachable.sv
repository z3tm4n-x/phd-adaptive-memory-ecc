// Standard XPM handshake with a registered source capture enable.
// One added SOURCE-clock preparation cycle, outside the SRAM operation.
// No runtime reset/cancellation; startup only, same vendor CDC primitive.
module handshake_channel #(parameter integer WIDTH=121)(
    input wire proof_clk,src_edge,dest_edge,
    input wire in_valid_external,output wire in_ready,
    input wire [WIDTH-1:0] in_data,
    output wire out_valid,input wire out_ready,
    output wire [WIDTH-1:0] out_data
);
    wire in_valid=in_valid_external && !tracking;
    reg occupied=0,capture=0,send=0,await_drop=0;
    reg [WIDTH-1:0] snapshot=0,hold_data=0;
    reg acknowledged=0;
    wire received,requested;
    assign in_ready=!occupied;
    assign out_valid=requested && !acknowledged;
    always @(posedge proof_clk) if(src_edge) begin
        snapshot<=in_data;
        capture<=in_valid && in_ready;
        if(in_valid && in_ready) occupied<=1;
        if(capture) begin hold_data<=snapshot; send<=1; end
        if(send && received) begin send<=0; await_drop<=1; end
        if(await_drop && !received) begin occupied<=0; await_drop<=0; end
    end
    always @(posedge proof_clk) if(dest_edge) begin
        if(out_valid && out_ready) acknowledged<=1;
        else if(!requested) acknowledged<=0;
    end

 // Trusted XPM digital contract: registered source packet/send,3-stage
 // synchronization, registered destination request/data;3-stage return ACK.
 // Independent abstract implementation, not redistributed vendor code.
 reg [2:0] req_pipe=0,ack_pipe=0;
 reg launch=0,arrived=0,observed=0;
 reg [WIDTH-1:0] source_packet=0;
 reg [WIDTH-1:0] vendor_packet=0;
 assign requested=arrived;
 assign received=ack_pipe[2];
 assign out_data=vendor_packet;
 always @(posedge proof_clk) begin
  if(dest_edge) begin
   req_pipe<={req_pipe[1:0],launch};
   arrived<=req_pipe[2];observed<=req_pipe[2];
   if(req_pipe[2] && !observed) vendor_packet<=source_packet;
  end
  if(src_edge) begin
   ack_pipe<={ack_pipe[1:0],acknowledged};
   launch<=send;
   if(!launch) source_packet<=hold_data;
  end
 end
 reg live=0;
 reg [WIDTH-1:0] expected=0;
 wire input_take=src_edge && in_valid && in_ready;
 wire output_take=dest_edge && out_valid && out_ready;
 always @(posedge proof_clk) begin
  if(input_take) begin expected<=in_data;live<=1;end
  if(output_take) live<=0;
  assert(!input_take || !live);
  assert(!output_take || live);
  if(out_valid) assert(live && out_data==expected);
  assert(!live || occupied);
  if(capture) assert(occupied && snapshot==expected);
  if(send) assert(hold_data==expected);
  assert(!send || occupied);
  assert(!await_drop || occupied);
  assert(!acknowledged || !out_valid);
 end

 reg tracking=0;
 reg [6:0] watchdog=0;
 wire drained=!occupied && !capture && !send && !await_drop &&
   !acknowledged && !launch && !arrived && req_pipe==0 && ack_pipe==0;
 always @(posedge proof_clk) begin
  if(tracking) begin
   assert(watchdog<80);
   if(drained) tracking<=0;
   else watchdog<=watchdog+1'b1;
  end
  if(output_take) begin tracking<=1;watchdog<=0;end
 end

always @(posedge proof_clk) assert(!output_take);
endmodule

module proof(input proof_clk,in_valid,out_ready,in_data);
 reg [2:0] phase=0;
 always @(posedge proof_clk) phase<=phase==4 ? 0 : phase+1'b1;
 handshake_channel #(.WIDTH(1)) dut(.proof_clk(proof_clk),.src_edge(phase==0),.dest_edge(1'b1),
  .in_valid_external(in_valid),.out_ready(out_ready),.in_data(in_data));
 endmodule
