
module proof(input wire fast_clk,forward_valid,return_ready,
 input wire [56:0] forward_data,input wire [18:0] control_word,
 input wire start_operation,select_app,finish_operation,err_request,
 input wire [31:0] read_data);
localparam WORD_BITS=19;
reg [1:0] calendar_phase=0;
reg selected_app=0,did_go=0;
wire control_prepare=calendar_phase==0 && start_operation && !select_app;
wire app_prepare=calendar_phase==0 && start_operation && select_app;
wire control_due=calendar_phase==1 && !selected_app;
wire app_due=calendar_phase==1 && selected_app;
wire busy=calendar_phase==2 && did_go;
wire err_due=busy && err_request;
wire release_due=busy && finish_operation && !err_due;
wire forward_ready;
wire app_grant_debug,grant_debug;
wire [56:0] grant_data_debug;
wire [18:0] prepared_word;
always @(posedge fast_clk) begin
 if(calendar_phase==0 && start_operation) begin calendar_phase<=1;selected_app<=select_app;end
 if(calendar_phase==1) begin calendar_phase<=2;did_go<=grant_debug;end
 if(calendar_phase==2 && (!did_go || release_due)) begin calendar_phase<=0;did_go<=0;end
end
    reg [56:0] app_snapshot=0,app_command=0,backend_command=57'h1e0000000000000;
    reg app_receipt=0,app_waiting=0,app_prepared=0;
    reg active_app=0,observed_err=0,reply_pending=0;
    reg [32:0] reply=0;
    assign forward_ready=!app_waiting && !app_receipt;
    assign app_grant_debug=app_due && app_prepared && !busy;
    assign grant_debug=control_due || app_grant_debug;
    assign grant_data_debug=backend_command;
    // Physical address is loaded from this already-prepared command by an
    // always-clocked I/O FF, on the unchanged GO edge. No busy/GO enable
    // fans out across the remote address bank. Command stability is proved.
    assign prepared_word=backend_command[20:2];
    wire backend_fault;
    reg application_fault=0;
    reg overlap_fault=0,outbox_fault=0;
    always @(posedge fast_clk) begin
        // Diagnostic pipeline is outside the atomic operation. It never
        // changes acceptance or suppresses a pending correction/response.
        overlap_fault<=grant_debug && busy;
        outbox_fault<=release_due && active_app && reply_pending && !return_ready;
        if(overlap_fault || outbox_fault) application_fault<=1;
        app_snapshot<=forward_data;
        app_receipt<=forward_valid && forward_ready;
        if(app_receipt) begin app_command<=app_snapshot; app_waiting<=1; end
        if(control_prepare) backend_command<={4'hf,32'd0,{{(19-WORD_BITS){1'b0}},control_word},2'd0};
        if(app_prepare) begin
            app_prepared<=app_waiting && !reply_pending;
            if(app_waiting && !reply_pending) backend_command<=app_command;
        end
        if(app_due) app_prepared<=0;
        if(grant_debug) begin
            active_app<=app_grant_debug; observed_err<=0;
            if(app_grant_debug) app_waiting<=1;
        end
        if(err_due) observed_err<=1;
        if(reply_pending && return_ready) reply_pending<=0;
        if(release_due && active_app) begin
            reply<={read_data,observed_err}; reply_pending<=1;
        end
    end

reg [56:0] expected[0:1];
reg head=0,tail=0;
reg [1:0] count=0;
reg executed=0,returnable=0,expected_err=0;
reg [32:0] expected_response=0;
wire take=forward_valid && forward_ready;
wire put=reply_pending && return_ready;
initial begin expected[0]=0;expected[1]=0;end
always @(posedge fast_clk) begin
 if(take) begin expected[tail]<=forward_data;tail<=!tail;end
 if(put) begin head<=!head;executed<=0;returnable<=0;end
 case({take,put})
  2'b10:count<=count+1'b1;
  2'b01:count<=count-1'b1;
 endcase
 if(grant_debug) expected_err<=0;
 if(err_due) expected_err<=1;
 if(app_grant_debug) executed<=1;
 if(release_due && active_app) begin
  expected_response<={read_data,expected_err};returnable<=1;
 end
 assert(count<=2);
 assert(count=={1'b0,app_receipt}+{1'b0,app_waiting}+{1'b0,executed});
 assert(!(app_receipt && app_waiting));
 assert(!executed || count>0);
 assert(!busy || active_app==selected_app);
 assert(!busy || !active_app || executed);
 assert(observed_err==expected_err);
 assert(head==tail || count==1);
 assert(head!=tail || count!=1);
 assert(calendar_phase<=2);
 assert(!returnable || !busy || !active_app);
 assert(!take || count<2 || put);
 if(app_receipt) assert(app_snapshot==expected[!tail]);
 if(app_waiting) assert(app_command==expected[!tail]);
 assert(!app_prepared || app_waiting);
 assert(!app_prepared || (calendar_phase==1 && selected_app && !reply_pending));
 if(app_prepared) assert(backend_command==app_command);
 assert(!overlap_fault && !outbox_fault);
 assert(!executed || returnable || (busy && active_app));
 assert(reply_pending==returnable);
 assert(!returnable || executed);
 if(app_grant_debug) begin
  assert(count>0 && !executed);
  assert(backend_command==expected[head]);
  assert(!busy);
 end
 if(release_due && active_app) assert(executed && !returnable);
 if(reply_pending) assert(reply==expected_response);
 if(put) assert(count>0 && executed && returnable);
 assert(!application_fault);
end
endmodule
