module proof(input [127:0] payload,input [63:0] generation);
wire [3:0] parts={payload[95:80]==generation[63:48],
                              payload[79:64]==generation[47:32],
                              payload[63:48]==generation[31:16],
                              payload[47:32]==generation[15:0]};
always @* assert(!(&parts) || payload[95:32]==generation);
endmodule
