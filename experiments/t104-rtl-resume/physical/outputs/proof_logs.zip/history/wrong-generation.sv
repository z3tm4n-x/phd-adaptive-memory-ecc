module proof(input fast_clk,history_change,loss_fast,err_due,input [63:0] uptime);
 reg [63:0] generation=0;
 always @(posedge fast_clk) if(history_change) generation<=generation+1'b1;
 reg event_capture=0,event_write=0;
 reg [65:0] event_snapshot=0;
 reg [129:0] event_staged=0;
 reg [129:0] expected0=0,expected1=0;
 reg [1:0] valid=0;
 always @(posedge fast_clk) begin
  expected0<={generation+64'd1,uptime,loss_fast,err_due};
  expected1<=expected0;
  valid<={valid[0],history_change};
  assert(event_write==valid[1]);
  if(event_write) assert(event_staged==expected1);
  if(event_capture) assert(generation==expected0[129:66]);
  if(event_capture) assert(event_snapshot==expected0[65:0]);
 end
    always @(posedge fast_clk) begin
        event_capture<=history_change;
        event_snapshot<={uptime,loss_fast,err_due};
        event_write<=event_capture;
        event_staged<={generation+64'd1,event_snapshot};
    end
endmodule
