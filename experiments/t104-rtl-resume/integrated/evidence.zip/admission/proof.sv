// Complete functional two-domain executor, with separate application, history
// and candidate paths. SRAM E is the proven registered backend, unchanged.
module integrated_executor #(
    parameter integer WORD_BITS=19,INVERSE=174763,
    parameter [33:0] NW=34'd4500045002,NH=34'd9000090002,NR=34'd9015504896,
    parameter [63:0] PAIR_WINDOW=64'd22500225010
)(
    input wire fast_clk,slow_clk,startup_rst_fast,startup_rst_slow,
    input wire qualified_start,loss_slow,
    input wire [1:0] request_valid,
    output wire [1:0] request_ready,
    input wire [241:0] request_data,
    output wire [1:0] response_valid,input wire [1:0] response_ready,
    output wire [96:0] response_data,
    input wire [15:0] dq_in,input wire err_in,
    output wire [WORD_BITS-1:0] word_out,
    output wire ce,oe,we,drive,alias_high,
    output wire [1:0] byte_enable,output wire [15:0] dq_out,
    output wire running,busy,pending,err_due,release_due,
    output wire grant_debug,app_grant_debug,
    output wire [56:0] grant_data_debug,
    output wire slot_pulse,skip_pulse,freeze_pulse,frozen_execute,
    output wire [63:0] generation,processed_generation,
    output wire rule_low,candidate_permit,
    output wire [33:0] short_left,long_left,recovery_left,
    output wire [31:0] frame_id,
    output wire [1:0] credits_debug,
    output wire fault
);
    // Slow application admission: two total credits including returned-but-
    // unconsumed replies. CPU wins simultaneous offers; aggregate envelope
    // still applies to first VALID, not to the arbitrarily delayed handshake.
    wire [120:0] req0=request_data[120:0],req1=request_data[241:121];
    wire owner=!request_valid[0];
    wire [120:0] chosen=owner?req1:req0;
    wire legal=(chosen[1:0]==1 || chosen[1:0]==2) && chosen[56:53]!=0 &&
               chosen[20:2]<(20'd1<<WORD_BITS);
    reg [1:0] credits=0;
    wire running_slow;
    wire forward_capacity,id_capacity,id_valid,returned_valid;
    wire [64:0] id_data;
    wire [32:0] returned_data;
    wire can_accept=running_slow && !startup_rst_slow && credits<2 && forward_capacity && id_capacity && legal;
    assign request_ready={can_accept && owner,can_accept && !owner};
    wire capture=|(request_valid & request_ready);
    wire consume=returned_valid && id_valid && response_ready[id_data[64]];
    assign response_valid={returned_valid && id_valid && id_data[64],
                           returned_valid && id_valid && !id_data[64]};
    assign response_data={id_data[63:0],returned_data};
    assign credits_debug=credits;
    always @(posedge slow_clk) begin
        case({capture,consume})
            2'b10:credits<=credits+1'b1;
            2'b01:credits<=credits-1'b1;
            default:credits<=credits;
        endcase
    end

(* anyseq *) reg pf_capacity,pf_return,pf_running;
(* anyseq *) reg [64:0] pf_id;
reg [4:0] pf_metadata_count=0;
assign running_slow=pf_running;
assign forward_capacity=pf_capacity;
assign returned_valid=pf_return;
assign returned_data=0;
assign id_data=pf_id;
assign id_capacity=pf_metadata_count<16;
assign id_valid=pf_metadata_count!=0;
always @(posedge slow_clk) begin
 // Standard lossless FIFO count semantics, depth16 as the actual slow_queue.
 case({capture,consume})
 2'b10:pf_metadata_count<=pf_metadata_count+1'b1;
 2'b01:pf_metadata_count<=pf_metadata_count-1'b1;
 endcase
 assert(credits<=2);
 assert(credits==pf_metadata_count);
 assert(!(request_ready[0] && request_ready[1]));
 assert(!capture || (credits<2 && forward_capacity && id_capacity && legal));
 assert(!consume || credits>0);
end
endmodule
