// Same deterministic schedule as the independent absolute Calendar reference.
// Four local decisions suffice for lead320 at c164. Candidate FRAME leases are
// separate, prepared two frames ahead, and never alter committed slot bits.
module frame_engine #(
    parameter integer WORD_BITS=19,INVERSE=174763
)(
    input wire clk,start,permit,alarm,backend_busy,
    output wire control_due,app_due,slot_due,freeze_due,
    output wire control_prepare,app_prepare,
    output reg [WORD_BITS-1:0] word_due,
    output reg running,fault,
    output wire frame_pulse,
    output reg [31:0] frame_id,freeze_frame,
    output reg [2:0] slot_pos,freeze_pos,
    output reg slot_pulse,skip_pulse,freeze_pulse,frozen_execute
);
    initial begin
        word_due=0;running=0;fault=0;frame_id=0;freeze_frame=0;slot_pos=0;freeze_pos=2;
        slot_pulse=0;skip_pulse=0;freeze_pulse=0;frozen_execute=0;
    end
    reg [6:0] start_wait=0,freeze_wait=2;
    reg [8:0] app_wait=328;
    reg [1:0] start_ring=0,freeze_ring=2,freeze_mod3=2;
    reg [WORD_BITS:0] warmup_left=(1<<WORD_BITS)-2;
    reg [3:0] decisions=4'b1111,valid_decisions=4'b0011;
    reg slot_tick=0,freeze_tick=0,app_tick=0,frame_tick=0;
    reg execute_slot=1;
    (* anyseq *) reg must_execute;
    assign slot_due=slot_tick;
    assign freeze_due=freeze_tick;
    assign frame_pulse=frame_tick;
    // A frozen bit is available 320xi before its slot. Select it in advance;
    // no ring mux is allowed on the backend GO edge. Never sample live LOW
    // here: that would revoke an already committed skip after a new ERR.
    assign control_due=slot_due && execute_slot;
    assign app_due=app_tick;
    assign control_prepare=running && start_wait==1;
    assign app_prepare=running && app_wait==1;
    always @(posedge clk) begin
        slot_pulse<=0; skip_pulse<=0; freeze_pulse<=0;
        execute_slot<=decisions[start_ring] || !valid_decisions[start_ring];
        if(start && !running) begin running<=1;slot_tick<=1;frame_tick<=1;end
        else if(running) begin
            slot_tick<=start_wait==1;
            freeze_tick<=freeze_wait==1;
            app_tick<=app_wait==1;
            frame_tick<=start_wait==1 && slot_pos==0;
            if(freeze_due) begin
                freeze_wait<=freeze_pos==7 ? 104 : 40;
                // A local lease tag, NOT mission time or error generation.
                // A frame transfer finishes <1us; a tag repeats after16
                // frames (>25us). In-contract transfer bounds are checked
                // separately; blockage faults, but is not priced as normal.
                if(freeze_pos==7) freeze_frame<=(freeze_frame+1'b1)&32'hf;
                freeze_pos<=freeze_pos+1'b1; freeze_ring<=freeze_ring+1'b1;
                freeze_mod3<=freeze_mod3==2 ? 0 : freeze_mod3+1'b1;
                if(warmup_left!=0) warmup_left<=warmup_left-1'b1;
                decisions[freeze_ring]<=must_execute || !permit || fault;
                valid_decisions[freeze_ring]<=1;
                freeze_pulse<=1; frozen_execute<=must_execute || !permit || fault;
            end else freeze_wait<=freeze_wait-1'b1;
            if(slot_due) begin
                start_wait<=slot_pos==7 ? 104 : 40;
                slot_pos<=slot_pos+1'b1; start_ring<=start_ring+1'b1;
                word_due<=word_due+INVERSE;
                slot_pulse<=1;
                if(!valid_decisions[start_ring] || (control_due && backend_busy)) fault<=1;
                if(!decisions[start_ring] && valid_decisions[start_ring]) skip_pulse<=1;
                valid_decisions[start_ring]<=0;
            end else start_wait<=start_wait-1'b1;
            if(app_wait==0) app_wait<=391;
            else app_wait<=app_wait-1'b1;
            // Frame number changes at its first edge, not the final slot.
            if(start_wait==1 && slot_pos==0) frame_id<=(frame_id+1'b1)&32'hf;
        end
    end

reg seen=0;
// Ghost phase is not an RTL input or an assumption. Its independently
// generated phase table is asserted against the actual local counters.
reg [8:0] proof_phase=0;
reg [6:0] expected_start,expected_freeze;
reg [8:0] expected_app;
reg [2:0] expected_slot,expected_freeze_pos;
always @* begin
 if(proof_phase==0) begin expected_start=0;expected_slot=0;end
 else if(proof_phase<=41) begin expected_start=41-proof_phase;expected_slot=1;end
 else if(proof_phase<=82) begin expected_start=82-proof_phase;expected_slot=2;end
 else if(proof_phase<=123) begin expected_start=123-proof_phase;expected_slot=3;end
 else if(proof_phase<=164) begin expected_start=164-proof_phase;expected_slot=4;end
 else if(proof_phase<=205) begin expected_start=205-proof_phase;expected_slot=5;end
 else if(proof_phase<=246) begin expected_start=246-proof_phase;expected_slot=6;end
 else if(proof_phase<=287) begin expected_start=287-proof_phase;expected_slot=7;end
 else begin expected_start=392-proof_phase;expected_slot=0;end
 if(proof_phase<=2) begin expected_freeze=2-proof_phase;expected_freeze_pos=2;end
 else if(proof_phase<=43) begin expected_freeze=43-proof_phase;expected_freeze_pos=3;end
 else if(proof_phase<=84) begin expected_freeze=84-proof_phase;expected_freeze_pos=4;end
 else if(proof_phase<=125) begin expected_freeze=125-proof_phase;expected_freeze_pos=5;end
 else if(proof_phase<=166) begin expected_freeze=166-proof_phase;expected_freeze_pos=6;end
 else if(proof_phase<=207) begin expected_freeze=207-proof_phase;expected_freeze_pos=7;end
 else if(proof_phase<=312) begin expected_freeze=312-proof_phase;expected_freeze_pos=0;end
 else if(proof_phase<=353) begin expected_freeze=353-proof_phase;expected_freeze_pos=1;end
 else begin expected_freeze=394-proof_phase;expected_freeze_pos=2;end
 expected_app=proof_phase<=328 ? 328-proof_phase : 720-proof_phase;
end
always @(posedge clk) begin
 seen<=1;
 if(running) proof_phase<=proof_phase==391 ? 0 : proof_phase+1'b1;
 assert(proof_phase<=391);
 assert(running || proof_phase==0);
 assert(start_wait==expected_start && slot_pos==expected_slot);
 assert(freeze_wait==expected_freeze && freeze_pos==expected_freeze_pos);
 assert(app_wait==expected_app);
 assert(start_ring==slot_pos[1:0] && freeze_ring==freeze_pos[1:0]);
 assert(start_wait<=104); assert(freeze_wait<=104); assert(app_wait<=391);
 assert(freeze_mod3<=2);
 assert(slot_tick==(running && start_wait==0));
 assert(freeze_tick==(running && freeze_wait==0));
 assert(app_tick==(running && app_wait==0));
 assert(frame_tick==(slot_tick && slot_pos==0));
 assert(!freeze_due || start_wait==39 || start_wait==80);
 if(freeze_due && start_wait==39) assert(freeze_ring!=start_ring);
 if(running && start_wait<=39) assert(execute_slot==(decisions[start_ring] || !valid_decisions[start_ring]));
 if(slot_pos==0) begin
   assert({1'b0,app_wait}=={3'b0,start_wait}+10'd328 ||
          {1'b0,app_wait}+10'd64=={3'b0,start_wait});
 end else begin
   assert(start_wait<=40);
   assert({1'b0,app_wait}=={3'b0,start_wait}+10'd328-10'd41*slot_pos);
 end
 assert(!control_due || slot_due);
 if(slot_due) assert(execute_slot==(decisions[start_ring] || !valid_decisions[start_ring]));
 assert(!(control_due && app_due));
 if(seen && $past(running)) begin
   assert(running);
   if($past(slot_due)) begin
      assert(start_wait==($past(slot_pos)==7?104:40));
      assert(word_due==$past(word_due)+WORD_BITS'(INVERSE));
      assert(start_ring==2'($past(start_ring)+1));
   end else begin assert(start_wait==$past(start_wait)-1'b1);assert(word_due==$past(word_due));end
   if($past(freeze_due)) begin
     assert(frozen_execute==$past(must_execute || !permit || alarm || fault));
     assert(freeze_wait==($past(freeze_pos)==7?104:40));
   end else assert(freeze_wait==$past(freeze_wait)-1'b1);
   if($past(app_due)) assert(app_wait==391);
   else assert(app_wait==$past(app_wait)-1'b1);
 end
end

endmodule

module proof(input wire clk,start,permit,alarm,backend_busy); frame_engine #(.WORD_BITS(3),.INVERSE(3)) dut(.clk(clk),.start(start),.permit(permit),.alarm(alarm),.backend_busy(backend_busy)); endmodule