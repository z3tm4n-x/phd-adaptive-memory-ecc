import re
bib={
'sto':"СТО ГК Роскосмос 04.01.0010–2025. Типовые методики расчётно-экспериментальной оценки стойкости комплектующих изделий электронной компонентной базы бортовой радиоэлектронной аппаратуры автоматических космических аппаратов к воздействию ионизирующего излучения космического пространства по одиночным радиационным эффектам.",
'saleh':"Saleh A. M., Serrano J. J., Patel J. H. Reliability of scrubbing recovery-techniques for memory systems // IEEE Transactions on Reliability. 1990. Vol. 39, No. 1. P. 114–122. DOI: 10.1109/24.52622.",
'gasiot':"Gasiot G., Giot D., Roche P. Multiple cell upsets as the key contribution to the total SER of 65 nm CMOS SRAMs and its dependence on well engineering // IEEE Transactions on Nuclear Science. 2007. Vol. 54, No. 6. P. 2468–2473. DOI: 10.1109/TNS.2007.908147.",
'boruzdina14':"Боруздина А. Б., Григорьев Н. Г., Уланова А. В. Влияние топологического размещения ячеек в микросхемах памяти на кратность сбоев от ТЗЧ // Микроэлектроника. 2014. Т. 43, № 2. С. 88–93. DOI: 10.7868/S0544126914020033.",
'chumakov':"Чумаков А. И. Радиационные эффекты в интегральных схемах. М.: Техносфера, 2024. 384 с. ISBN 978-5-94836-707-1.",
'boruzdina16':"Боруздина А. Б., Темирбулатов М. С., Печенкин А. А. и др. Особенности экспериментальных методов исследования микросхем памяти с помехоустойчивым кодированием данных // Проблемы разработки перспективных микро- и наноэлектронных систем. 2016. № 4. С. 184–189.",
'an88889':"Cypress Semiconductor (Infineon Technologies). AN88889. Mitigating Single-Event Upsets Using Cypress’s 65-nm Asynchronous SRAM. Document No. 001-88889 Rev. *C. 2015.",
'tausch':"Tausch H. J. Simplified birthday statistics and Hamming EDAC // IEEE Transactions on Nuclear Science. 2009. Vol. 56, No. 2. P. 474–478. DOI: 10.1109/TNS.2009.2012710.",
'podzolko':"Подзолко М. В. Моделирование опасности одиночных сбоев от космических частиц для памяти с коррекцией ошибок // Вестник Московского университета. Серия 3: Физика. Астрономия. 2017. № 6. С. 99–106 (Moscow University Physics Bulletin. 2017. Vol. 72, No. 6. P. 601–608. DOI: 10.3103/S0027134917060133).",
'clemente22':"Clemente J. A., Rezaei M., Franco F. J. Reliability of error correction codes against multiple events by accumulation // IEEE Transactions on Nuclear Science. 2022. Vol. 69, No. 2. P. 169–180. DOI: 10.1109/TNS.2022.3143652.",
'rezaei23':"Rezaei M., Franco F. J., Hubert G., Clemente J. A. A method to neutralize the impact of DVS on the reliability of COTS SRAMs with ECC by using periodic scrubbing // IEEE Transactions on Nuclear Science. 2023. Vol. 70, No. 12. P. 2578–2589. DOI: 10.1109/TNS.2023.3332635.",
'krasnikov':"Красников Г. Я., Лушников А. С., Мещанов В. Д. и др. Исследование сбоеустойчивости СОЗУ с функцией исправления одиночных сбоев при воздействии ТЗЧ // Электронная техника. Серия 3: Микроэлектроника. 2018. № 1 (169). С. 68–76.",
'shchigorev':"Щигорев Л. А. Эффективность методов повышения сбое- и отказоустойчивости блоков статической оперативной памяти // Микроэлектроника. 2022. Т. 51, № 4. С. 313–320. DOI: 10.31857/S054412692204010X.",
'reviriego10':"Reviriego P., Maestro J. A., Baeg S. et al. Protection of memories suffering MCUs through the selection of the optimal interleaving distance // IEEE Transactions on Nuclear Science. 2010. Vol. 57, No. 4. P. 2124–2128. DOI: 10.1109/TNS.2010.2042818.",
'lee11':"Lee S., Baeg S., Reviriego P. Memory reliability model for accumulated and clustered soft errors // IEEE Transactions on Nuclear Science. 2011. Vol. 58, No. 5. P. 2483–2492. DOI: 10.1109/TNS.2011.2164555.",
'wu15':"Wu W., Seifert N. MBU-Calc: A compact model for multi-bit upset (MBU) SER estimation // 2015 IEEE International Reliability Physics Symposium (IRPS). 2015. P. SE.2.1–SE.2.6. DOI: 10.1109/IRPS.2015.7112831.",
'zebrev17':"Zebrev G. I., Galimov A. M., Mrozovskaya L. V. et al. Multiple cell upset partitioning for simulation of soft error rates in space systems with error correcting codes // arXiv:1704.07271v2. 2017.",
'wirthlin14':"Wirthlin M., Lee D., Swift G., Quinn H. A method and case study on identifying physically adjacent multiple-cell upsets using 28-nm, interleaved and SECDED-protected arrays // IEEE Transactions on Nuclear Science. 2014. Vol. 61, No. 6. P. 3080–3087. DOI: 10.1109/TNS.2014.2366913.",
'clemente16':"Clemente J. A., Franco F. J., Villa F. et al. Statistical anomalies of bitflips in SRAMs to discriminate SBUs from MCUs // IEEE Transactions on Nuclear Science. 2016. Vol. 63, No. 4. P. 2087–2094. DOI: 10.1109/TNS.2016.2551263.",
'guo22':"Guo J., Mao G., Liu W. et al. The bitmap decryption model on interleaved SRAM using multiple-bit upset analysis // IEEE Transactions on Nuclear Science. 2022. Vol. 69, No. 8. P. 1857–1864. DOI: 10.1109/TNS.2022.3186083.",
'lelape':"Clemente J. A., Rezaei M., Fabero J. C. et al. LELAPE: An open-source tool to classify SEUs according to their multiplicity in radiation-ground tests on memories // IEEE Transactions on Nuclear Science. 2024. Vol. 71, No. 10. P. 2260–2271. DOI: 10.1109/TNS.2024.3450607.",
'dataset':"Coronetti A., Matana Luza L., Bosser A. et al. MCU data in a Cypress 65 nm SRAM from heavy ions and protons collected at ground facilities [Data set]. Zenodo, 2023. DOI: 10.5281/zenodo.8314389.",
'redw20':"Coronetti A., Cecchetto M., Wang J. et al. SEU characterization of commercial and custom-designed SRAMs based on 90 nm technology and below // 2020 IEEE Radiation Effects Data Workshop (REDW). 2020. P. 56–63. DOI: 10.1109/REDW51883.2020.9325822.",
'coronetti25':"Coronetti A., García-Alía R., Dilillo L. et al. SRAM-based heavy-ion beam flux and LET dosimetry // IEEE Transactions on Nuclear Science. 2025. Vol. 72, No. 8. P. 2458–2465. DOI: 10.1109/TNS.2024.3487647.",
'tsiligiannis14':"Tsiligiannis G. et al. Multiple cell upset classification in commercial SRAMs // IEEE Transactions on Nuclear Science. 2014. Vol. 61, No. 4. P. 1747–1754. DOI: 10.1109/TNS.2014.2313742.",
'bosser15':"Bosser A., Gupta V., Tsiligiannis G. et al. Investigation on MCU clustering methodologies for cross-section estimation of RAMs // IEEE Transactions on Nuclear Science. 2015. Vol. 62, No. 6. P. 2620–2626. DOI: 10.1109/TNS.2015.2496874.",
'alia23':"García Alía R. et al. Heavy ion energy deposition and SEE intercomparison within the RADNEXT irradiation facility network // IEEE Transactions on Nuclear Science. 2023. Vol. 70, No. 8. P. 1596–1605. DOI: 10.1109/TNS.2023.3260309.",
'cosrad':"Кузнецов Н. В., Малышкин Ю. М., Николаева Н. И. и др. Программный комплекс COSRAD для прогнозирования радиационных условий на борту космических аппаратов // Вопросы атомной науки и техники. Серия: Физика радиационного воздействия на радиоэлектронную аппаратуру. 2011. № 2. С. 72–78.",
'coronetti21':"Coronetti A., García Alía R., Wang J. et al. Assessment of proton direct ionization for the radiation hardness assurance of deep submicron SRAMs used in space applications // IEEE Transactions on Nuclear Science. 2021. Vol. 68, No. 5. P. 937–948. DOI: 10.1109/TNS.2021.3061209.",
'hansen24':"Hansen D. L. et al. A review of single-event upset-rate calculation methods // IEEE Transactions on Nuclear Science. 2024. DOI: 10.1109/TNS.2024.3451312.",
'zebrev26':"Зебрев Г. И., Родин А. С., Матейко А. А. Метод аналитической оценки частоты одиночных сбоев от галактических космических лучей в цифровой электронике // Безопасность информационных технологий. 2026. Т. 33, № 2. DOI: 10.26583/bit.2026.2.03.",
'datasheet':"Infineon Technologies AG. CY62167G/CY62167GE MoBL, 16-Mbit (1M words × 16-bit / 2M words × 8-bit) Static RAM with Error-Correcting Code (ECC). Data Sheet. Document No. 001-81537.",
'kato19':"Kato T., Yamazaki T., Saito N., Matsuyama H. Neutron-induced multiple-cell upsets in 20-nm bulk SRAM: Angular sensitivity and impact of multiwell potential perturbation // IEEE Transactions on Nuclear Science. 2019. Vol. 66, No. 7. P. 1381–1389. DOI: 10.1109/TNS.2019.2900629.",
'gomi26':"Gomi Y., Takami K., Yasuda R. et al. Quasi event-wise measurement and simulation of neutron-induced multiple-cell upsets in 22-nm and 55-nm SRAMs // IEEE Transactions on Nuclear Science. 2026. DOI: 10.1109/TNS.2026.3675003.",
}
src=open('article_v18_src.md',encoding='utf-8').read()
order=[]
for m in re.finditer(r'\[(@[^\]]+)\]',src):
    for k in re.findall(r'@([A-Za-z0-9_]+)',m.group(1)):
        if k not in order: order.append(k)
missing=[k for k in order if k not in bib]; assert not missing, missing
num={k:i+1 for i,k in enumerate(order)}
def fmt(nums):
    nums=sorted(set(nums)); out=[]; i=0
    while i<len(nums):
        j=i
        while j+1<len(nums) and nums[j+1]==nums[j]+1: j+=1
        out.append(f"{nums[i]}–{nums[j]}" if j-i>=2 else ", ".join(str(n) for n in nums[i:j+1]))
        i=j+1
    return "["+", ".join(out)+"]"
out=re.sub(r'\[(@[^\]]+)\]',lambda m: fmt([num[k] for k in re.findall(r'@([A-Za-z0-9_]+)',m.group(1))]),src)
out=out.rstrip()+"\n\n"+"\n".join(f"{num[k]}. {bib[k]}" for k in order)+"\n"
open('article_v18.md','w',encoding='utf-8').write(out)
print(len(order),"references; unused in bib:",[k for k in bib if k not in num])
