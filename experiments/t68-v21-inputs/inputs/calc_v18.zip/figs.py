import numpy as np, pickle, math
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, LogLocator
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.grid':True,'grid.alpha':0.3})
comma=FuncFormatter(lambda v,p: (f"{v:g}").replace('.',','))
runs=pickle.load(open('runs.pkl','rb'))
# ---------- Fig A: cluster extent tails ----------
sel=[('Ar1050MeV','Ar, 5,2'),('U190.4GeV','U, 15'),('XeLET27','Xe, 27'),('U35.7GeV','U, 33'),('XeLET42','Xe, 42'),('Xe2700MeV','Xe, 44'),('XeLET57','Xe, 57')]
fig,axs=plt.subplots(1,2,figsize=(9,3.8),sharey=True)
cols=plt.cm.viridis(np.linspace(0,0.9,len(sel)))
for (k,lab),c in zip(sel,cols):
    ev=runs[k]; dy=np.array([e['ys'].max()-e['ys'].min() for e in ev]); dx=np.array([e['xs'].max()-e['xs'].min() for e in ev])
    d=np.arange(0,23)
    for ax,v in ((axs[0],dy),(axs[1],dx)):
        s=np.array([(v>=di).mean() for di in d]); s[s==0]=np.nan
        ax.semilogy(d,s,'o-',ms=3,color=c,label=lab)
for ax,t in ((axs[0],'Протяжённость по y (Δy, строк)'),(axs[1],'Протяжённость по x (Δx, столбцов)')):
    ax.axvline(16,color='r',ls='--',lw=1); ax.set_xlabel(t); ax.set_xlim(0,22); ax.set_xticks([0,4,8,12,16,20])
axs[0].set_ylabel('Доля событий с протяжённостью ≥ d')
axs[0].text(16.3,0.5,'Δ = 16',color='r'); axs[1].text(16.3,0.5,'Δ = 16',color='r')
axs[1].legend(title='Ион, ЛПЭ, МэВ·см²/мг',fontsize=8,title_fontsize=8,loc='center right',bbox_to_anchor=(0.98,0.45))
axs[0].set_title('а',loc='left'); axs[1].set_title('б',loc='left')
plt.tight_layout(); plt.savefig('fig/fig3_extent.png',dpi=200); plt.close()
# ---------- Fig B: LET spectra and sigma1 models ----------
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
T=10*365.25*86400; Teff=8e4
col=5  # 2.5 g/cm2
Lf,phi=make_phi(col,gl); Lfs,phis=make_phi(col,sl); phis=np.where(Lfs<=31.7,phis,0.0)
def integ(Lf,phi): 
    c=np.concatenate([[0],np.cumsum(0.5*(phi[1:]+phi[:-1])*np.diff(Lf))]); return c[-1]-c
IG=integ(Lf,phi)*T; IS=integ(Lfs,phis)*Teff
fig,axs=plt.subplots(2,1,figsize=(6.5,7))
ax=axs[0]
ax.loglog(Lf,IG,'k-',label='ГКЛ, 10 лет (пиковая плотность потока)')
m=IS>0; ax.loglog(Lfs[m],IS[m],'b--',label='СКЛ, $T_{эф}$ = 8·10⁴ с')
ax.set_ylabel('Флюенс частиц с ЛПЭ > L, см⁻²'); ax.set_ylim(1e-3,1e8)
ax.axvspan(27,33,color='orange',alpha=0.25,label='ЛПЭ 27–33 МэВ·см²/мг')
ax.legend(fontsize=8,loc='lower left'); ax.set_title('а',loc='left')
ax=axs[1]
L=np.logspace(np.log10(20),np.log10(100),600)
def s_pt2(L): return np.where(L<=33,np.nan,np.interp(L,[33,43,57],[0.0,5.501e-5,3.343e-4]))
def s_env(L): return np.where(L>=57,1.090e-3,np.where(L>=43,3.368e-4,np.where(L>=27,1.438e-4,np.nan)))
def s_real(L): return np.where(L>=27,6.623e-5,np.nan)
ax.loglog(L,s_pt2(L),'k-',label='точечная оценка (группировки с A0)')
ax.loglog(L,s_env(L),'r-',label='верхняя 95%-я граница (группировки с A0)')
ax.loglog(L,s_real(L),'g--',label='верхняя 95%-я граница (слово в одной строке)')
ax.errorbar([43,57],[5.501e-5,3.343e-4],fmt='ko',ms=5)
ax.plot([30],[1.438e-4],'rv',ms=6)
ax.set_xlabel('ЛПЭ, МэВ·см²/мг'); ax.set_ylabel('σ₁, см²'); ax.set_ylim(1e-6,3e-3)
ax.axvspan(27,33,color='orange',alpha=0.25)
ax.legend(fontsize=8,loc='lower right'); ax.set_title('б',loc='left')
axs[0].set_xlim(0.1,120); axs[0].xaxis.set_major_formatter(comma); axs[0].set_xlabel('ЛПЭ, МэВ·см²/мг')
axs[1].set_xlim(20,100); axs[1].set_xticks([20,30,40,50,60,80,100]); axs[1].xaxis.set_major_formatter(comma); axs[1].xaxis.set_minor_formatter(FuncFormatter(lambda v,p: ''))
plt.tight_layout(); plt.savefig('fig/fig4_let_sigma1.png',dpi=200); plt.close()
# ---------- Fig C: tau_max vs shielding ----------
out=pickle.load(open('tau.pkl','rb'))
rho=np.array([o[0] for o in out]); tG=np.array([o[4] for o in out]); t1=np.array([o[5] for o in out]); t1lo=np.array([o[6] for o in out]); t1hi=np.array([o[7] for o in out]); t2=np.array([o[8] for o in out])
fig,ax=plt.subplots(figsize=(6.5,4.2))
ax.semilogy(rho,tG,'ko-',label='только ГКЛ')
ax.semilogy(rho,t1,'bs-',label='ГКЛ + СКЛ (спектр ЛПЭ)')
ax.fill_between(rho,t1lo,t1hi,color='b',alpha=0.15,label='$T_{эф}$ = 6·10⁴…1,1·10⁵ с')
ax.semilogy(rho,t2,'r^-',label='ГКЛ + СКЛ, с прямой ионизацией протонами')
for y,lab in ((0.189,'чтение + запись всех 2²¹ адресов'),(0.094,'только чтение всех 2²¹ адресов (ERR)'),(0.047,'чтение + запись 2¹⁹ слов'),(0.024,'только чтение 2¹⁹ слов (ERR)')):
    ax.axhline(y,color='gray',ls=':',lw=1); ax.text(4.02,y*1.05,lab,fontsize=7,color='dimgray',ha='right')
ax.set_xlabel('Поверхностная плотность алюминиевой защиты, г/см²'); ax.set_ylabel('$\\tau_{max}$, с')
ax.xaxis.set_major_formatter(comma); ax.set_xlim(1.45,4.05); ax.set_ylim(2e-3,500)
ax.legend(fontsize=8,loc='center left',bbox_to_anchor=(0.0,0.62))
plt.tight_layout(); plt.savefig('fig/fig5_tau.png',dpi=200); plt.close()
print("ok")
