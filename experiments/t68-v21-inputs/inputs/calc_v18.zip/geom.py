import pickle, numpy as np
runs=pickle.load(open('runs.pkl','rb'))
LET={'C1080MeV':0.23,'C720MeV':0.31,'C360MeV':0.53,'Ar1050MeV':5.2,'Ar548MeV':7.9,'U190.4GeV':15,'U142.8GeV':17,'U78.5GeV':22,
     'XeLET27':27,'U45.2GeV':29,'U35.7GeV':33,'XeLET42':42,'Xe2700MeV':44,'XeLET57':57}
print("run        LET   N     S    m_mean  m_max  frac(dy>=16)  frac(dy>=8) mean_dy mean_dx  max_dy max_dx  N1main")
for k in sorted(LET,key=lambda s:LET[s]):
    evs=runs[k]
    dy=np.array([e['ys'].max()-e['ys'].min() for e in evs]); dx=np.array([e['xs'].max()-e['xs'].min() for e in evs])
    m=np.array([e['m'] for e in evs])
    n1=sum(1 for e in evs if any((d[0] & ~3)==0 for d in e['D']))
    print(f"{k:10s} {LET[k]:5.2f} {len(evs):5d} {m.sum():6d} {m.mean():6.2f} {m.max():5d}   {np.mean(dy>=16):8.4f}   {np.mean(dy>=8):8.4f}   {dy.mean():6.2f} {dx.mean():6.2f}   {dy.max():5d} {dx.max():5d}   {n1}")
# details of first-type events (main grouping)
print("\nFirst-type events (main grouping A0,A1):")
for k in ['XeLET42','XeLET57']:
    for idx,e in enumerate(runs[k]):
        pairs=[d[0] for d in e['D'] if (d[0] & ~3)==0]
        if pairs:
            # list the same-word cell pairs
            a=e['a']; xs=e['xs']; ys=e['ys']; m=e['m']
            pl=[]
            for i in range(m):
                for j in range(i+1,m):
                    if (int(a[i]^a[j]) & ~3)==0:
                        pl.append(((int(xs[i]),int(ys[i])),(int(xs[j]),int(ys[j])),int(a[i]^a[j])))
            print(f" {k} event#{idx}: m={m} dy={ys.max()-ys.min()} dx={xs.max()-xs.min()} pairs={pl}")
# protons: y-extent stats
print()
for k in ['p40MeV','p80MeV','p124MeV','p164MeV','p186MeV','p29MeV','p1MeV','p3MeV']:
    evs=runs[k]; dy=np.array([e['ys'].max()-e['ys'].min() for e in evs]); m=np.array([e['m'] for e in evs])
    print(f"{k:8s} N={len(evs):6d} m_mean={m.mean():.3f} m_max={m.max():3d} frac(dy>=16)={np.mean(dy>=16):.5f} max_dy={dy.max()}")
