import pickle, numpy as np
exec(open('pileup.py').read().split("Ncells=2**24")[0].replace("def merge_area(evs,n=2000,r=3):","def _unused(evs,n=2000,r=3):"))
rng=np.random.default_rng(7)
Ncells=2**24
def area_by_gap(evs,n=500,G=7):
    acc=np.zeros(G+1)
    for _ in range(n):
        i,j=rng.integers(0,len(evs),2)
        A=np.stack([evs[i]['xs'],evs[i]['ys']],1); B=np.stack([evs[j]['xs'],evs[j]['ys']],1)
        D=set(map(tuple,(A[:,None,:]-B[None,:,:]).reshape(-1,2)))
        # min L1 distance field over translations within bounding window
        xs=[d[0] for d in D]; ys=[d[1] for d in D]
        x0,x1,y0,y1=min(xs)-G,max(xs)+G,min(ys)-G,max(ys)+G
        W=np.full((x1-x0+1,y1-y0+1),10**6)
        for (dx,dy) in D: W[dx-x0,dy-y0]=0
        # L1 distance transform (two passes)
        for i2 in range(W.shape[0]):
            for j2 in range(W.shape[1]):
                if i2>0: W[i2,j2]=min(W[i2,j2],W[i2-1,j2]+1)
                if j2>0: W[i2,j2]=min(W[i2,j2],W[i2,j2-1]+1)
        for i2 in range(W.shape[0]-1,-1,-1):
            for j2 in range(W.shape[1]-1,-1,-1):
                if i2<W.shape[0]-1: W[i2,j2]=min(W[i2,j2],W[i2+1,j2]+1)
                if j2<W.shape[1]-1: W[i2,j2]=min(W[i2,j2],W[i2,j2+1]+1)
        for g in range(G+1): acc[g]+=np.sum(W==g)
    return acc/n
for run in ['U190.4GeV','U45.2GeV','XeLET27','XeLET42','Xe2700MeV','XeLET57']:
    evs=runs[run]; N=len(evs); pairs=N*(N-1)/2
    h=near_pairs(evs)
    exp=area_by_gap(evs,300)*pairs/Ncells
    row=' '.join(f"g{g}: obs {h.get(g,0):2d} / rnd {exp[g]:4.1f}" for g in range(4,8))
    print(f"{run:10s} {row}")
