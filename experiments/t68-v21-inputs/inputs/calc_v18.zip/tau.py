import pickle, math
R=pickle.load(open('geo.pkl','rb'))
Q=1e-3; T=10*365.25*86400; beta=31/(2*2**24)
print("rho |  N1(pt2)  k*(pt2) k*(art) | tau_GCR  | tau_GCR+SEP(LET) [Teff 6e4..1.1e5]   | tau_GCR+SEP(+PDI)")
out=[]
for r in R:
    N1=r['N1G_pt2']+r['N1S_pt2']; P1=1-math.exp(-N1)
    kpt=-math.log(1-Q)/N1; kart=-math.log(1-Q)/(r['N1G_art'])
    tG=(Q-P1)/(beta*T*r['nuG']**2)
    def tS(nuS,Te): return (Q-P1)/(beta*(T*r['nuG']**2+Te*nuS**2))
    t1=tS(r['nuS'],8e4); t1lo=tS(r['nuS'],1.1e5); t1hi=tS(r['nuS'],6e4)
    t2=tS(r['nuSpdi'],8e4)
    out.append((r['rho'],N1,kpt,kart,tG,t1,t1lo,t1hi,t2))
    print(f"{r['rho']:4.2f} | {N1:.2e} {kpt:6.1f} {kart:6.1f} | {tG:7.1f}  | {t1:7.3f} [{t1lo:.3f}..{t1hi:.3f}]  | {t2:7.4f}")
pickle.dump(out,open('tau.pkl','wb'))
print("\nInterface: full pass times: read+write 2^19: %.3f s, 2^21: %.3f s; read-only (ERR) 2^19: %.3f s, 2^21: %.3f s"%(2**19*90e-9,2**21*90e-9,2**19*45e-9,2**21*45e-9))
