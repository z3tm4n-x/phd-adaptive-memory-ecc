import pickle, numpy as np
from collections import defaultdict
exec(open('pileup.py').read().split("def merge_area")[0].replace("runs=pickle.load(open('runs.pkl','rb'))","runs=pickle.load(open('runs.pkl','rb'))"))
adm=[(0,1),(0,2),(0,3),(0,5),(0,8),(0,10),(0,11),(0,12),(0,13),(0,15)]
row=[(2,3),(2,8),(3,8)]
def pairs_close(evs,maxd=7,cell=32):
    boxes=[(e['xs'].min(),e['xs'].max(),e['ys'].min(),e['ys'].max()) for e in evs]
    grid=defaultdict(list)
    for i,(x0,x1,y0,y1) in enumerate(boxes):
        for gx in range(x0//cell,x1//cell+1):
            for gy in range(y0//cell,y1//cell+1): grid[(gx,gy)].append(i)
    out=[]
    seen=set()
    for i,(x0,x1,y0,y1) in enumerate(boxes):
        for gx in range((x0-maxd)//cell,(x1+maxd)//cell+1):
            for gy in range((y0-maxd)//cell,(y1+maxd)//cell+1):
                for j in grid.get((gx,gy),[]):
                    if j>i and (i,j) not in seen:
                        seen.add((i,j))
                        A=np.stack([evs[i]['xs'],evs[i]['ys']],1); B=np.stack([evs[j]['xs'],evs[j]['ys']],1)
                        d=int(np.abs(A[:,None,:]-B[None,:,:]).sum(-1).min())
                        if d<=maxd: out.append((i,j,d))
    return out
for run in ['U45.2GeV','XeLET27','XeLET42','Xe2700MeV','XeLET57']:
    evs=runs[run]
    cp=pairs_close(evs)
    hitsA0=0; hitsRow=0; detail=[]
    for i,j,d in cp:
        if d<4: continue   # separated in time (not merged by the algorithm) -> treat as distinct events
        a=np.concatenate([evs[i]['a'],evs[j]['a']])
        na=len(evs[i]['a'])
        X=(evs[i]['a'][:,None]^evs[j]['a'][None,:])
        def has(groups):
            for (p,q) in groups:
                mask=(1<<p)|(1<<q)
                if np.any((X & ~mask)==0): return True
            return False
        hA=has([(0,1)]); hAny=has(adm); hR=has(row)
        if hA or hAny or hR:
            detail.append((i,j,d,len(evs[i]['a']),len(evs[j]['a']),'main' if hA else ('A0-any' if hAny else ''),'row' if hR else ''))
        hitsA0+=hA; hitsRow+=hR
    merged_dy=[ (i,j,d) for i,j,d in cp if d>=4]
    print(f"{run:10s} near pairs gap4-7: {sum(1 for _,_,d in cp if d>=4)}; cross-pairs forming same-word pair: main grouping {hitsA0}, row groupings {hitsRow}; details {detail[:6]}")
