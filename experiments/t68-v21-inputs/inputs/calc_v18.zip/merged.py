import pickle, numpy as np, itertools
from collections import defaultdict
runs=pickle.load(open('runs.pkl','rb'))
HI=['C1080MeV','C720MeV','C360MeV','Ar1050MeV','Ar548MeV','U190.4GeV','U142.8GeV','U78.5GeV','XeLET27','U45.2GeV','U35.7GeV','XeLET42','Xe2700MeV','XeLET57']
A0=[(0,1),(0,2),(0,3),(0,5),(0,8),(0,10),(0,11),(0,12),(0,13),(0,15)]
ROW=[(2,3),(2,8),(3,8)]
good=[0,1,2,3,5,8,10,11,12,13,15]
ADM=list(itertools.combinations(good,2)); assert len(ADM)==55
def merge_events(evs,maxd=5,cell=32):
    n=len(evs); parent=list(range(n))
    def f(i):
        while parent[i]!=i: parent[i]=parent[parent[i]]; i=parent[i]
        return i
    boxes=[(e['xs'].min(),e['xs'].max(),e['ys'].min(),e['ys'].max()) for e in evs]
    grid=defaultdict(list)
    for i,(x0,x1,y0,y1) in enumerate(boxes):
        for gx in range(x0//cell,x1//cell+1):
            for gy in range(y0//cell,y1//cell+1): grid[(gx,gy)].append(i)
    seen=set()
    for i,(x0,x1,y0,y1) in enumerate(boxes):
        for gx in range((x0-maxd)//cell,(x1+maxd)//cell+1):
            for gy in range((y0-maxd)//cell,(y1+maxd)//cell+1):
                for j in grid.get((gx,gy),[]):
                    if j<=i or (i,j) in seen: continue
                    seen.add((i,j))
                    bi,bj=boxes[i],boxes[j]
                    if max(0,bj[0]-bi[1],bi[0]-bj[1])+max(0,bj[2]-bi[3],bi[2]-bj[3])>maxd: continue
                    A=np.stack([evs[i]['xs'],evs[i]['ys']],1); B=np.stack([evs[j]['xs'],evs[j]['ys']],1)
                    dmin=np.abs(A[:,None,:]-B[None,:,:]).sum(-1).min()
                    if 4<=dmin<=maxd:
                        parent[f(i)]=f(j)
    groups=defaultdict(list)
    for i in range(n): groups[f(i)].append(i)
    out=[]
    for g in groups.values():
        xs=np.concatenate([evs[k]['xs'] for k in g]); ys=np.concatenate([evs[k]['ys'] for k in g]); a=np.concatenate([evs[k]['a'] for k in g])
        u=sorted(set(zip(xs.tolist(),ys.tolist(),a.tolist())))
        xs=np.array([p[0] for p in u]); ys=np.array([p[1] for p in u]); a=np.array([p[2] for p in u])
        out.append({'a':a,'xs':xs,'ys':ys,'parts':len(g)})
    return out
def smu_count(evs,grouping):
    mask=(1<<grouping[0])|(1<<grouping[1]); c=0
    for e in evs:
        a=e['a']
        if len(a)<2: continue
        X=a[:,None]^a[None,:]
        iu=np.triu_indices(len(a),1)
        if np.any((X[iu] & ~mask)==0): c+=1
    return c
res={}
for r in HI:
    mev=merge_events(runs[r])
    nmerged=sum(1 for e in mev if e['parts']>1)
    cnt={g:smu_count(mev,g) for g in ADM}
    res[r]=dict(N=len(runs[r]),Nm=len(mev),nmerged=nmerged,cnt=cnt)
    a0=[cnt[g] for g in A0]; row=[cnt[g] for g in ROW]; other=[cnt[g] for g in ADM if g not in A0 and g not in ROW]
    print(f"{r:10s} clusters={len(runs[r]):6d} merged events={len(mev):6d} (multi-part: {nmerged:3d}) | SMU (A0,A1)={cnt[(0,1)]}  A0-class min..max={min(a0)}..{max(a0)}  row={row}  other42 max={max(other)}")
pickle.dump(res,open('merged.pkl','wb'))
