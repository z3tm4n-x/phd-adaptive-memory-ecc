import numpy as np, math, json
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])   # defines make_phi, rate_naive, sig_nak, sig_p_710, etc. (res1 tables loaded)
exec(open('sep.py').read().split("print(\"SEP proton spectrum")[0].split("exec(open('orbital.py')")[1].split("\n",1)[1])  # rate_pl, sig_p_pdi
def rd(fn,ncol):
    rows=[]
    for line in open('res2/results/'+fn,encoding='latin-1'):
        p=line.split()
        if len(p)==ncol:
            try: rows.append([float(v) for v in p])
            except: pass
    return np.array(rows)
gl2=rd('gl_x.txt',9); sl2=rd('sl_x.txt',9); gp2=rd('gp_x.txt',9); sp2=rd('sp_x.txt',9)
sh2=[0.1,0.2,0.27,0.3,0.5,0.7,1.0,1.25]
V=json.load(open('v17.json'))
Q=1e-3; T=10*365.25*86400; k=38/32; beta38=37/(2*38*2**19); Teff=1.34*86400
def s_pt(L): L=np.asarray(L,float); return np.where(L<=33,0.0,np.interp(L,[33,43,57],[0.0,V['s43'],V['s57']]))
rows=[]
for i,rho in enumerate(sh2):
    col=i+1
    Lf,phi=make_phi(col,gl2); Lfs,phis=make_phi(col,sl2); phis=np.where(Lfs<=31.7,phis,0.0)
    nuG=rate_naive(Lf,phi,sig_nak)+rate_pl(col,gp2,sig_p_710)*Nbits
    nuS=rate_naive(Lfs,phis,sig_nak)+rate_pl(col,sp2,sig_p_710)*Nbits
    nuSp=rate_naive(Lfs,phis,sig_nak)+rate_pl(col,sp2,sig_p_pdi)*Nbits
    L1=T*rate_naive(Lf,phi,s_pt)
    rows.append(dict(rho=rho,nuG=nuG,nuS=nuS,nuSp=nuSp,L1pt=L1))
for r in V['rows']:
    rows.append(dict(rho=r['rho'],nuG=r['nuG'],nuS=r['nuS'],nuSp=r['nuSp'],L1pt=r['L1pt']))
rows.sort(key=lambda r:r['rho'])
passes=[('знач. группировка + ERR',0.024),('знач. группировка',0.047),('все адреса + ERR',0.094),('все адреса',0.189)]
print(" rho  | nuG,1e-4/s nuS,1/s  (PDI) | L1pt     k*  | tau GCR-only | tau uniform (v18) | tau PDI | constant continuous scrubbing satisfies (2) with:")
for r in rows:
    nuG=r['nuG']*k; nuS=r['nuS']*k; nuSp=r['nuSp']*k; P1=1-math.exp(-r['L1pt'])
    tG=(Q-P1)/(beta38*T*nuG**2)
    tu=(Q-P1)/(beta38*(T*nuG**2+Teff*nuS*(nuS+2*nuG)))
    tp=(Q-P1)/(beta38*(T*nuG**2+Teff*nuSp*(nuSp+2*nuG)))
    ok=[lab for lab,p in passes if tu>=p]
    okp=[lab for lab,p in passes if tp>=p]
    ks=-math.log(1-Q)/r['L1pt'] if r['L1pt']>0 else float('inf')
    print(f"{r['rho']:5.2f} | {r['nuG']*1e4:6.2f}  {r['nuS']:8.3f} ({r['nuSp']:7.3f}) | {r['L1pt']:.2e} {ks:5.0f} | {tG:7.1f} s | {tu:9.4f} s | {tp:8.4f} | {', '.join(ok) if ok else 'ни один'} || PDI: {', '.join(okp) if okp else 'ни один'}")
