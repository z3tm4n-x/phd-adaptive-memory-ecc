import numpy as np, math, json, pickle
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
exec(open('sep.py').read().split("print(\"SEP proton spectrum")[0].split("exec(open('orbital.py')")[1].split("\n",1)[1])
def rd(fn,ncol):
    rows=[]
    for line in open('res2/results/'+fn,encoding='latin-1'):
        p=line.split()
        if len(p)==ncol:
            try: rows.append([float(v) for v in p])
            except: pass
    return np.array(rows)
sets=[(rd('gl_x.txt',9),rd('sl_x.txt',9),rd('gp_x.txt',9),rd('sp_x.txt',9),[0.1,0.2,0.27,0.3,0.5,0.7,1.0,1.25]),
      (gl,sl,gp,sp,list(shield))]
tab=pickle.load(open('tab.pkl','rb'))
Q=1e-3; T=10*365.25*86400; Teff=1.34*86400; k=38/32; beta38=37/(2*38*2**19); th=0.3
tH={1:3.3,2:2.7,3:2.4,4:2.2,5:2.1,6:2.0}
runs=[(27,'XeLET27'),(29,'U45.2GeV'),(33,'U35.7GeV'),(42,'XeLET42'),(44,'Xe2700MeV'),(57,'XeLET57')]
F={L:tab[r]['Fn'] for L,r in runs}
N_A0={27:0,29:0,33:0,42:2,44:0,57:4}; N_row={L:0 for L,_ in runs}
Ls=[L for L,_ in runs]
def bound(Nd,Fd,extra=None):
    out={}
    for Li in Ls:
        sN=sum(Nd[L] for L in Ls if L>=Li); sF=sum(Fd[L] for L in Ls if L>=Li)
        if extra: sF+=extra
        out[Li]=(3.0 if sN==0 else tH[sN]*(0.67+sN))/((1-th)*sF)
    return out
def env_fun(b):
    def f(L):
        L=np.asarray(L,float); out=np.zeros_like(L)
        for i,Li in enumerate(Ls):
            lo=27 if i==0 else Ls[i-1]
            m=(L>lo)&(L<=Li) if i>0 else (L>=27)&(L<=Li)
            out[m]=b[Li]
        out[L>57]=b[57]
        return out
    return f
V=json.load(open('v17.json'))
def s_pt(L): L=np.asarray(L,float); return np.where(L<=33,0.0,np.interp(L,[33,43,57],[0.0,V['s43'],V['s57']]))
bA0=bound(N_A0,F); bRow=bound(N_row,F)
print("envelope A0:",{L:f"{v:.2e}" for L,v in bA0.items()})
print("envelope row:",{L:f"{v:.2e}" for L,v in bRow.items()})
passes=[('kg+ERR',0.024),('kg',0.047),('all+ERR',0.094),('all',0.189)]
out=[]
for (glx,slx,gpx,spx,shl) in sets:
    for i,rho in enumerate(shl):
        col=i+1
        Lf,phi=make_phi(col,glx); Lfs,phis=make_phi(col,slx); phis=np.where(Lfs<=31.7,phis,0.0)
        nuG=(rate_naive(Lf,phi,sig_nak)+rate_pl(col,gpx,sig_p_710)*Nbits)*k
        nuS=(rate_naive(Lfs,phis,sig_nak)+rate_pl(col,spx,sig_p_710)*Nbits)*k
        nuSp=(rate_naive(Lfs,phis,sig_nak)+rate_pl(col,spx,sig_p_pdi)*Nbits)*k
        L1=T*rate_naive(Lf,phi,s_pt); P1=1-math.exp(-L1)
        tG=(Q-P1)/(beta38*T*nuG**2)
        tU=(Q-P1)/(beta38*(T*nuG**2+Teff*nuS*(nuS+2*nuG)))
        tP=(Q-P1)/(beta38*(T*nuG**2+Teff*nuSp*(nuSp+2*nuG)))
        eA0=env_fun(bA0); eR=env_fun(bRow)
        UA0=T*rate_naive(Lf,phi,eA0)+Teff*rate_naive(Lfs,phis,eA0)
        UR=T*rate_naive(Lf,phi,eR)+Teff*rate_naive(Lfs,phis,eR)
        # required new zero-SMU fluence at LET>=57 for the row class so that UB<=5e-4
        def UBrow(extra):
            e=env_fun(bound(N_row,F,extra)); return T*rate_naive(Lf,phi,e)+Teff*rate_naive(Lfs,phis,e)
        lo,hi=0.0,1e8
        for _ in range(60):
            mid=(lo+hi)/2
            if UBrow(mid)>5e-4: lo=mid
            else: hi=mid
        Freq=hi+sum(F.values())   # total fluence at LET>=27 incl. existing
        ok=[l for l,p in passes if tU>=p]; okp=[l for l,p in passes if tP>=p]
        out.append(dict(rho=rho,nuG=nuG,nuS=nuS,nuSp=nuSp,L1=L1,kstar=-math.log(1-Q)/L1,tG=tG,tU=tU,tP=tP,UA0=UA0,UR=UR,Fadd=hi,ok=ok,okp=okp))
out.sort(key=lambda r:r['rho'])
json.dump(dict(bA0=bA0,bRow=bRow,rows=out,F=F),open('v18.json','w'),indent=1)
print(" rho | nuG(38) nuS(38) | L1pt  k* | tG     tU      tP     | UB A0   UB row | new F at LET>=57 (row) | feasible const.cont. | PDI")
for r in out:
    print(f"{r['rho']:4.2f} | {r['nuG']:.2e} {r['nuS']:7.3f} | {r['L1']:.1e} {r['kstar']:3.0f} | {r['tG']:6.1f} {r['tU']:.4f} {r['tP']:.4f} | {r['UA0']:.1e} {r['UR']:.1e} | {r['Fadd']:.2e} | {r['ok']} | {r['okp']}")
