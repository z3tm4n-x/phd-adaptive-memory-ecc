import numpy as np, math, pickle
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
T=10*365.25*86400; Teff=8e4
seg=lambda a,b: (lambda L: ((np.asarray(L)>=a)&(np.asarray(L)<b)).astype(float))
print("rho | exposure E(a,b)=T*Phi_G(a..b)+Teff*Phi_S(a..b)  [cm^2 -> events per unit sigma1]")
out={}
for i,rho in enumerate(shield):
    col=i+1
    Lf,phi=make_phi(col,gl); Lfs,phis=make_phi(col,sl); phis=np.where(Lfs<=31.7,phis,0.0)
    E={}
    for a,b in [(27,43),(43,57),(57,200),(33,200),(27,200)]:
        E[(a,b)]=(T*rate_naive(Lf,phi,seg(a,b)), Teff*rate_naive(Lfs,phis,seg(a,b)))
    out[rho]=E
    print(f"{rho:4.2f} | 27-43: G {E[(27,43)][0]:.3e} S {E[(27,43)][1]:.3e} | 43-57: G {E[(43,57)][0]:.3e} | >=57: G {E[(57,200)][0]:.3e} | >=33 G {E[(33,200)][0]:.3e}")
pickle.dump(out,open('exposure.pkl','wb'))
# required zero-event fluence in [27,43) so that N1 <= q, given env upper bounds above 43
q_alloc=5e-4
print("\nRequired fluence (zero first-type events) in LET 27..42 so that N1<=5e-4 (A0 grouping, env bounds above 43):")
for rho in (1.5,2.0,2.5,3.0,4.0):
    E=out[rho]
    rest=3.368e-4*sum(E[(43,57)])+1.090e-3*sum(E[(57,200)])
    e2743=sum(E[(27,43)])
    if rest>=q_alloc: print(rho,"infeasible: segments above 43 alone give",rest); continue
    sig_needed=(q_alloc-rest)/e2743
    Phi=3.0/((1-0.1)*sig_needed)
    print(f"  rho={rho}: N1 from >=43 segments (UB) = {rest:.2e}; sigma1 needed in 27-43 <= {sig_needed:.2e} cm2 -> fluence >= {Phi:.2e} cm^-2 (current {23179+0:.0f} in 27-33)")
print("\nRealistic grouping: required total zero-event fluence at LET>=27 so that N1<=5e-4:")
for rho in (1.5,2.0,2.5,3.0,4.0):
    e=sum(out[rho][(27,200)]); sig=5e-4/e; Phi=3.0/(0.9*sig)
    print(f"  rho={rho}: exposure {e:.3e}; sigma1<= {sig:.2e} -> fluence >= {Phi:.2e} (current 50333)")
