import pickle, numpy as np
rng=np.random.default_rng(1)
runs=pickle.load(open('runs.pkl','rb'))
def R_for(run,npairs=3000):
    evs=runs[run]; num=0; den=0
    idx=rng.integers(0,len(evs),size=(npairs,2))
    for i,j in idx:
        A=np.stack([evs[i]['xs'],evs[i]['ys']],1); B=np.stack([evs[j]['xs'],evs[j]['ys']],1)
        D=(A[:,None,:]-B[None,:,:]).reshape(-1,2)
        nd=len({(int(a),int(b)) for a,b in D})
        num+=len(A)*len(B); den+=nd
    return num/den
for run,L in [('p124MeV','p124'),('Ar1050MeV',5.2),('U190.4GeV',15),('U78.5GeV',22),('XeLET27',27),('U35.7GeV',33),('XeLET42',42),('Xe2700MeV',44),('XeLET57',57)]:
    print(f"{run:10s} LET={L}:  R = E[m_A m_B]/E[|A-B|] = {R_for(run):.2f}")
