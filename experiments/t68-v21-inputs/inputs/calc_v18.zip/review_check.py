import json, math, numpy as np
V=json.load(open('v17.json'))
Q=1e-3; T=10*365.25*86400
k=38/32; Nb38=38*2**19; beta38=(38-1)/(2*Nb38); beta32=31/(2*2**24)
print("factor beta*nu^2 (38 vs 32):", beta38*k*k/beta32)
passes={'известная группировка, запись по ERR':0.024,'известная группировка':0.047,'все адреса, запись по ERR':0.094,'все адреса':0.189}
print("\nrho | tau_uniform old(v17) -> new (n=38, Teff=1.12e5, cross term) | cross-term share | adaptive: quiet period allowed with continuous scrubbing during SEP")
for r in V['rows']:
    nuG=r['nuG']*k; nuS=r['nuS']*k; P1=1-math.exp(-r['L1pt'])
    for Teff,lab in ((8e4,'8e4'),(1.12e5,'1.12e5')):
        pass
    Teff=1.12e5
    den=T*nuG**2+Teff*nuS*(nuS+2*nuG)
    tu=(Q-P1)/(beta38*den)
    cross=Teff*2*nuG*nuS/den
    ad={}
    for lab,p in passes.items():
        rest=Q-P1-beta38*p*Teff*nuS*(nuS+2*nuG)
        ad[lab]=rest/(beta38*T*nuG**2) if rest>0 else float('nan')
    print(f"{r['rho']:4.2f} | {r['tS']:.3f} -> {tu:.3f} s | {cross:.2%} | "+"; ".join(f"{l}: {v:.0f} с" if v==v else f"{l}: невозможно" for l,v in ad.items()))
# reviewer's example at 2.0
r=[x for x in V['rows'] if x['rho']==2.0][0]
print("\nReviewer example (n=32, Teff=8e4) at 2.0: GCR@100s =",beta32*100*T*r['nuG']**2," SEP@0.04719 =",beta32*0.04719*8e4*r['nuS']**2," SMU =",r['L1pt'])
# monotone envelope for 'one row' (zero events everywhere): sigma(L) <= 3/(0.9*sum F_i over runs with L_i>=L)
runsL=[(27,9186),(29,9691),(33,4302),(42,9355),(44,8825),(57,8975)]
print("\nMonotone zero-event envelope (one-row class):")
for L,_ in runsL:
    s=sum(F for Li,F in runsL if Li>=L); print(f"  L<={L}: sigma_H <= {3/(0.9*s):.2e}")
print("single run 57:",3/(0.9*8975))
