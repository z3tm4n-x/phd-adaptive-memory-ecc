import pickle, numpy as np, math
runs=pickle.load(open('runs.pkl','rb')); n1=pickle.load(open('n1.pkl','rb'))
Nbits=2**24
ssat,L0w,W,h=2.6e-7,0.15,70.0,1.2
def sb(L): 
    x=max(L-L0w,0)/W; return ssat*(1-math.exp(-x**h)) if L>L0w else 0.0
Adie=0.1316; cov_sat=0.86
def cov(L): # coverage Weibull from [18]: LET0=0.15, sat 0.86, W=5, s=1.1
    x=max(L-0.15,0)/5.0; return cov_sat*(1-math.exp(-x**1.1)) if L>0.15 else 0.0
LET={'C1080MeV':0.23,'C720MeV':0.31,'C360MeV':0.53,'Ar1050MeV':5.2,'Ar548MeV':7.9,'U190.4GeV':15,'U142.8GeV':17,'U78.5GeV':22,
     'XeLET27':27,'U45.2GeV':29,'U35.7GeV':33,'XeLET42':42,'Xe2700MeV':44,'XeLET57':57}
print("run        LET    N      S    F_norm(Weib)  F_cov(N/(c*A))  F_cov/F_norm   sigma_nak(norm)  sigma_nak(cov)   N1  sigma1(norm) sigma1(cov)")
tab={}
for k in sorted(LET,key=lambda s:LET[s]):
    evs=runs[k]; N=len(evs); S=sum(e['m'] for e in evs); L=LET[k]
    N1,S1=n1[k][(0,1)]
    Fn=S/(Nbits*sb(L))
    c=cov(L); Fc=N/(c*Adie) if c>0 else float('nan')
    Snak=S-S1
    tab[k]=dict(L=L,N=N,S=S,N1=N1,S1=S1,Fn=Fn,Fc=Fc,Snak=Snak)
    print(f"{k:10s} {L:5.2f} {N:6d} {S:6d}  {Fn:11.1f}   {Fc:11.1f}      {Fc/Fn:6.2f}        {Snak/Fn:10.3f}      {Snak/Fc:10.3f}    {N1}  {N1/Fn:10.2e}  {N1/Fc:10.2e}")
pickle.dump(tab,open('tab.pkl','wb'))
# pooled fluences
def pool(keys,which): return sum(tab[k][which] for k in keys)
for which in ('Fn','Fc'):
    F2733=pool(['XeLET27','U45.2GeV','U35.7GeV'],which); F4244=pool(['XeLET42','Xe2700MeV'],which); F57=tab['XeLET57'][which]
    Fge27=pool(['XeLET27','U45.2GeV','U35.7GeV','XeLET42','Xe2700MeV','XeLET57'],which)
    print(f"\n[{which}] pooled F(27-33)={F2733:.0f}  F(42-44)={F4244:.0f}  F(57)={F57:.0f}  F(>=27)={Fge27:.0f}")
    th=0.10
    print(f"  point: sigma1(42-44)={1/F4244:.3e}  sigma1(57)={3/F57:.3e}")
    print(f"  UB95 (STO 6.5, z=3): [27-33] {3.0/((1-th)*F2733):.3e} ; realistic grouping all>=27: {3.0/((1-th)*Fge27):.3e}")
    print(f"  UB95 (STO 6.7): [42-44] n=1 tH=3.3: {3.3*(1+0.67)/((1-th)*F4244):.3e} ; [57] n=3 tH=2.4: {2.4*(3+0.67)/((1-th)*F57):.3e}")
    # Poisson exact 95% UL for comparison
    from scipy.stats import chi2
    ul=lambda n: chi2.ppf(0.95,2*(n+1))/2
    print(f"  exact Poisson UL95: [27-33] {ul(0)/F2733:.3e}  [42-44] {ul(1)/F4244:.3e}  [57] {ul(3)/F57:.3e}")
