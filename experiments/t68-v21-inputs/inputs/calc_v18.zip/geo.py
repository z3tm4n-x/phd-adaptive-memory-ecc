import numpy as np, math, pickle
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
exec(open('sep.py').read().split("print(\"SEP proton spectrum")[0].split("exec(open('orbital.py')")[1].split("\n",1)[1])
Q=1e-3; T=10*365.25*86400; Teff=8.0e4; beta=31/(2*2**24)
def s_art(L): return sig1_point(L)
def s_pt2(L):
    L=np.asarray(L,float); return np.where(L<=33,0.0,np.interp(L,[33,43,57],[0.0,5.501e-5,3.343e-4]))
def s_step33(L): return np.where(np.asarray(L)>=33,1.0896e-3,0.0)
def s_env(L):
    L=np.asarray(L,float)
    return np.where(L>=57,1.090e-3,np.where(L>=43,3.368e-4,np.where(L>=27,1.438e-4,0.0)))
def s_real(L): return np.where(np.asarray(L)>=27,6.623e-5,0.0)
models={'art':s_art,'pt2':s_pt2,'step33':s_step33,'env':s_env,'real':s_real}
def phi_knee_step(Lf,phi,table,col):
    Ln=table[:,0]/1000; ph=table[:,col]*1000
    i1=np.argmin(abs(Ln-31.6)); i2=np.argmin(abs(Ln-39.8))
    m=(Lf>Ln[i1])&(Lf<Ln[i2]); out=phi.copy(); out[m]=ph[i2]; return out
R=[]
for i,rho in enumerate(shield):
    col=i+1
    Lf,phi=make_phi(col,gl); Lfs,phis=make_phi(col,sl); phis=np.where(Lfs<=31.7,phis,0.0)
    phik=phi_knee_step(Lf,phi,gl,col)
    nuG=rate_naive(Lf,phi,sig_nak)+rate_pl(col,gp,sig_p_710)*Nbits
    nuGt=rate_thin(Lf,phi,sig_nak,60,200)+rate_pl(col,gp,sig_p_710)*Nbits
    nuS=rate_naive(Lfs,phis,sig_nak)+rate_pl(col,sp,sig_p_710)*Nbits
    nuSpdi=rate_naive(Lfs,phis,sig_nak)+rate_pl(col,sp,sig_p_pdi)*Nbits
    r=dict(rho=rho,nuG=nuG,nuGt=nuGt,nuS=nuS,nuSpdi=nuSpdi)
    for name,s in models.items():
        r['N1G_'+name]=T*rate_naive(Lf,phi,s)
        r['N1Gk_'+name]=T*rate_naive(Lf,phik,s)
        r['N1S_'+name]=Teff*rate_naive(Lfs,phis,s)
        r['N1Gt_'+name]=T*rate_thin(Lf,phi,s,60,200)
        r['N1St_'+name]=Teff*rate_thin(Lfs,phis,s,60,200)
    R.append(r)
pickle.dump(R,open('geo.pkl','wb'))
print("rho | nuG(/s)  nuG_thin | nuS_peak nuS_peak+PDI | ratio A_S/A_G (no PDI)")
for r in R:
    AG=T*r['nuG']**2; AS=Teff*r['nuS']**2
    print(f"{r['rho']:4.2f} | {r['nuG']:.3e} {r['nuGt']:.3e} | {r['nuS']:.3e} {r['nuSpdi']:.3e} | {AS/AG:8.0f}")
print("\nExpected first-type events over the mission, N1 = N1_GCR(10y) + N1_SEP  [naive model]; in brackets knee-step GCR interpolation")
print("rho |  art(G)          pt2(G)         step33(G)       env(G)+S          real(G)+S")
for r in R:
    f=lambda m: f"{r['N1G_'+m]:.2e}[{r['N1Gk_'+m]:.1e}]+{r['N1S_'+m]:.1e}"
    print(f"{r['rho']:4.2f} | {f('art')} | {f('pt2')} | {f('step33')} | {f('env')} | {f('real')}")
print("\nThin-slab (effective-LET) variant for N1 (illustrative):")
for r in R:
    print(f"{r['rho']:4.2f} | art {r['N1Gt_art']:.2e}+{r['N1St_art']:.1e} | pt2 {r['N1Gt_pt2']:.2e}+{r['N1St_pt2']:.1e} | env {r['N1Gt_env']:.2e}+{r['N1St_env']:.1e} | real {r['N1Gt_real']:.2e}+{r['N1St_real']:.1e}")
