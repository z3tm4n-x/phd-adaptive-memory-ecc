import numpy as np, pickle, math
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
runs=pickle.load(open('runs.pkl','rb')); n1=pickle.load(open('n1.pkl','rb'))
T=10*365.25*86400; Teff=8e4
hep=['p29MeV','p40MeV','p80MeV','p124MeV','p164MeV','p186MeV']
Ftot=0
for k in hep:
    S=sum(e['m'] for e in runs[k]); N=len(runs[k])
    F=S/(Nbits*8e-14); Ftot+=F
    dy=np.array([e['ys'].max()-e['ys'].min() for e in runs[k]])
    print(f"{k:8s} N={N:6d} S={S:6d} F~{F:.2e} p/cm2  N(dy>=16)={int((dy>=16).sum())}  N1(A0,A1)={n1[k][(0,1)][0]} N1(A0,A11)={n1[k][(0,11)][0]}")
print(f"total HEP proton fluence ~ {Ftot:.2e} p/cm2")
sH=3.0/(0.9*Ftot); spt=1.0/Ftot
print(f"sigma1_p: point (A0,A11) = {spt:.2e} cm2;  UB95 main grouping (0 events) = {sH:.2e} cm2")
def Fp_int(col,table,Emin=20.0):
    E=table[:,0]; f=table[:,col]
    Ef=np.logspace(np.log10(E[0]),np.log10(E[-1]),40001)
    ff=np.exp(np.interp(np.log(Ef),np.log(E),np.log(np.where(f>0,f,1e-300)))); ff[ff<1e-290]=0
    return 0.5*np.trapezoid(ff*(Ef>=Emin),Ef)
print("\nrho | GCR p flux(>20MeV)/2 [1/cm2/s] | SEP peak p flux(>20)/2 | exposure GCR 10y + SEP [cm^-2] | N1_p point(A0,A11) | N1_p UB(main)")
for i,rho in enumerate(shield):
    col=i+1
    g=Fp_int(col,gp); s=Fp_int(col,sp)
    expo=T*g+Teff*s
    print(f"{rho:4.2f} | {g:.3e} | {s:.3e} | {expo:.3e} (G {T*g:.2e}, S {Teff*s:.2e}) | {spt*expo:.2e} | {sH*expo:.2e}")
