import numpy as np, pickle, json
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.grid':True,'grid.alpha':0.3})
comma=FuncFormatter(lambda v,p: (f"{v:g}").replace('.',','))
runs=pickle.load(open('runs.pkl','rb')); V=json.load(open('v17.json'))
# ---------- Fig 2: example cluster + extent tails ----------
ev=[e for e in runs['XeLET42'] if e['m']==43][0]
xs,ys,a=ev['xs'],ev['ys'],ev['a']
pairs=[(i,j) for i in range(len(a)) for j in range(i+1,len(a)) if (int(a[i]^a[j]) & ~3)==0]
fig=plt.figure(figsize=(11,4.2))
ax0=fig.add_axes([0.075,0.13,0.20,0.78])
inpair=set([i for p in pairs for i in p])
ax0.scatter([xs[i] for i in range(len(xs)) if i not in inpair],[ys[i] for i in range(len(ys)) if i not in inpair],marker='s',s=28,c='lightgray',edgecolors='gray',label='ошибочные ячейки')
cols=['tab:orange','tab:green','tab:red']
for k,(i,j) in enumerate(pairs):
    ax0.scatter([xs[i],xs[j]],[ys[i],ys[j]],marker='s',s=40,c=cols[k%3],edgecolors='k',label=f'пара слова {k+1}')
    ax0.annotate('',xy=(xs[i]+0.45,ys[i]),xytext=(xs[j]+0.45,ys[j]),arrowprops=dict(arrowstyle='<->',color=cols[k%3],lw=1))
ax0.set_xlabel('x (столбец)'); ax0.set_ylabel('y (строка)'); ax0.set_title('а',loc='left')
ax0.set_xticks(range(int(xs.min()),int(xs.max())+1)); ax0.set_xlim(xs.min()-0.8,xs.max()+1.2)
ax0.set_yticks(range(int(ys.min()),int(ys.max())+1,4)); ax0.set_ylim(ys.min()-1,ys.max()+1)
sel=[('Ar1050MeV','Ar, 5,2'),('U190.4GeV','U, 15'),('XeLET27','Xe, 27'),('U35.7GeV','U, 33'),('XeLET42','Xe, 42'),('Xe2700MeV','Xe, 44'),('XeLET57','Xe, 57')]
colsv=plt.cm.viridis(np.linspace(0,0.9,len(sel)))
ax1=fig.add_axes([0.35,0.13,0.29,0.78]); ax2=fig.add_axes([0.70,0.13,0.29,0.78],sharey=ax1)
for (k,lab),c in zip(sel,colsv):
    e=runs[k]; dy=np.array([q['ys'].max()-q['ys'].min() for q in e]); dx=np.array([q['xs'].max()-q['xs'].min() for q in e])
    d=np.arange(0,23)
    for ax,v in ((ax1,dy),(ax2,dx)):
        s=np.array([(v>=di).mean() for di in d]); s[s==0]=np.nan
        ax.semilogy(d,s,'o-',ms=3,color=c,label=lab)
for ax,t,lab in ((ax1,'Протяжённость по y (Δy), строк','б'),(ax2,'Протяжённость по x (Δx), столбцов','в')):
    ax.axvline(16,color='r',ls='--',lw=1); ax.set_xlabel(t); ax.set_xlim(0,22); ax.set_xticks([0,4,8,12,16,20]); ax.set_title(lab,loc='left')
    ax.text(16.3,0.5,'16',color='r')
ax1.set_ylabel('Доля событий с протяжённостью ≥ d')
ax2.legend(title='Ион, ЛПЭ, МэВ·см²/мг',fontsize=7,title_fontsize=7,loc='center right',bbox_to_anchor=(0.99,0.45))
plt.savefig('fig/v17_fig2.png',dpi=200); plt.close()
# ---------- Fig 3: tau vs shielding ----------
R=V['rows']; rho=np.array([r['rho'] for r in R]); tG=np.array([r['tG'] for r in R]); tS=np.array([r['tS'] for r in R]); tSp=np.array([r['tSp'] for r in R])
fig,ax=plt.subplots(figsize=(6.5,4.2))
ax.semilogy(rho,tG,'ko-',label='только ГКЛ')
ax.semilogy(rho,tS,'bs-',label='ГКЛ + СКЛ')
ax.fill_between(rho,tS*0.73,tS*1.33,color='b',alpha=0.15,label='$T_{эф}$ = 6·10⁴…1,1·10⁵ с')
ax.semilogy(rho,tSp,'r^--',label='ГКЛ + СКЛ, с прямой ионизацией протонами')
for y,lab in ((0.189,'чтение и запись всех 2²¹ адресов'),(0.094,'чтение всех 2²¹ адресов, запись по ERR'),(0.047,'чтение и запись 2¹⁹ слов'),(0.024,'чтение 2¹⁹ слов, запись по ERR')):
    ax.axhline(y,color='gray',ls=':',lw=1); ax.text(4.02,y*1.06,lab,fontsize=7,color='dimgray',ha='right')
ax.set_xlabel('Поверхностная плотность алюминиевой защиты, г/см²'); ax.set_ylabel('Допустимый период скраббинга, с')
ax.xaxis.set_major_formatter(comma); ax.set_xlim(1.45,4.05); ax.set_ylim(2e-3,500)
ax.legend(fontsize=8,loc='center left',bbox_to_anchor=(0.0,0.64))
plt.tight_layout(); plt.savefig('fig/v17_fig3.png',dpi=200); plt.close()
# ---------- Fig 4: spectra + sigma1 ----------
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
T=10*365.25*86400; Teff=8e4; col=5
Lf,phi=make_phi(col,gl); Lfs,phis=make_phi(col,sl); phis=np.where(Lfs<=31.7,phis,0.0)
def integ(Lf,phi):
    c=np.concatenate([[0],np.cumsum(0.5*(phi[1:]+phi[:-1])*np.diff(Lf))]); return c[-1]-c
IG=integ(Lf,phi)*T; IS=integ(Lfs,phis)*Teff
fig,axs=plt.subplots(2,1,figsize=(6.5,7))
ax=axs[0]; ax.loglog(Lf,IG,'k-',label='ГКЛ, 10 лет'); m=IS>0; ax.loglog(Lfs[m],IS[m],'b--',label='СКЛ, $T_{эф}$ = 8·10⁴ с')
ax.set_ylabel('Флюенс частиц с ЛПЭ > L, см⁻²'); ax.set_ylim(1e-3,1e8); ax.axvspan(27,33,color='orange',alpha=0.25,label='ЛПЭ 27–33 МэВ·см²/мг')
ax.legend(fontsize=8,loc='lower left'); ax.set_title('а',loc='left'); ax.set_xlim(0.1,120); ax.xaxis.set_major_formatter(comma); ax.set_xlabel('ЛПЭ, МэВ·см²/мг')
ax=axs[1]; L=np.logspace(np.log10(20),np.log10(100),600)
spt=np.where(L<=33,np.nan,np.interp(L,[33,43,57],[0.0,V['s43'],V['s57']]))
senv=np.where(L>=57,V['ub57'],np.where(L>=43,V['ub4244'],np.where(L>=27,V['ub2733'],np.nan)))
srow=np.where(L>=27,V['ubrow'],np.nan)
ax.loglog(L,spt,'k-',label='точечная оценка, слово в разных строках')
ax.loglog(L,senv,'r-',label='верхняя граница 0,95, слово в разных строках')
ax.loglog(L,srow,'g--',label='верхняя граница 0,95, слово в одной строке')
ax.plot([43,57],[V['s43'],V['s57']],'ko',ms=5)
ax.set_xlabel('ЛПЭ, МэВ·см²/мг'); ax.set_ylabel('Сечение SMU, см²'); ax.set_ylim(1e-6,3e-3)
ax.axvspan(27,33,color='orange',alpha=0.25); ax.legend(fontsize=8,loc='lower right'); ax.set_title('б',loc='left')
ax.set_xlim(20,100); ax.set_xticks([20,30,40,50,60,80,100]); ax.xaxis.set_major_formatter(comma); ax.xaxis.set_minor_formatter(FuncFormatter(lambda v,p:''))
plt.tight_layout(); plt.savefig('fig/v17_fig4.png',dpi=200); plt.close()
print("ok", len(pairs))
