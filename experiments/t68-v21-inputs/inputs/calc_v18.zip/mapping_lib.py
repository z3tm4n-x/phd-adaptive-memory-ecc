import numpy as np
# Affine GF(2) map from the article's appendix: coordinates (x,y) -> external address A (21 bits)
M = {0:("y4",), 1:("y11",), 2:(1,"x10","x11"), 3:(1,"x9","x11"), 4:(1,"x8","x11"), 5:(1,"y10","y11"),
     6:(1,"x3","x8"), 7:("y0",), 8:(1,"x7","x8"), 9:(1,"x2","x8"), 10:("y8",), 11:("y5",), 12:("y6",),
     13:("y7",), 14:("y3",), 15:("y9",), 16:("y2",), 17:("y1",), 18:(1,"x0","x8"), 19:(1,"x1","x8"), 20:("x11",)}
def addr_vec(x,y):
    x=np.asarray(x,dtype=np.int64); y=np.asarray(y,dtype=np.int64)
    bit=lambda v,i:(v>>i)&1
    a=np.zeros_like(x)
    for k,terms in M.items():
        v=np.zeros_like(x)
        for t in terms:
            if t==1: v^=1
            else: v^=bit(x if t[0]=='x' else y,int(t[1:]))
        a|=v<<k
    return a
def word_id(x,y,bits):
    """word = group of 4 addresses differing only in the two address bits in `bits`"""
    a=addr_vec(x,y)
    mask=0
    for b in bits: mask|=(1<<b)
    return a & ~mask   # canonical representative
