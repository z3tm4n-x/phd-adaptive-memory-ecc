import pickle, numpy as np
from mapping_lib import addr_vec
data=pickle.load(open('data.pkl','rb'))
tot=bad=0; perfile={}
for k,cl in data.items():
    xs=[];ys=[];as_=[]
    for c in cl:
        if set(c['cells'])=={(0,0)}: continue
        for (x,y),a in zip(c['cells'],c['addr']):
            if a is not None: xs.append(x);ys.append(y);as_.append(a)
    if xs:
        pred=addr_vec(xs,ys); n=len(xs); nb=int((pred!=np.array(as_)).sum())
        perfile[k]=(n,nb); tot+=n; bad+=nb
print(perfile)
print("records with address:",tot," mismatches:",bad)
# unique (x,y,a) combos
u=set()
for k,cl in data.items():
    for c in cl:
        if set(c['cells'])=={(0,0)}: continue
        for (x,y),a in zip(c['cells'],c['addr']):
            if a is not None: u.add((x,y,a))
print("unique (x,y,A) combos:",len(u))
