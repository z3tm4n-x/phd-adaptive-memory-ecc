import numpy as np, pickle
d=np.load('cosrad.npz'); gl=d['gl']; sl=d['sl']; gp=d['gp']; sp=d['sp']; shield=d['shield']
rates=pickle.load(open('cosrad_rates.pkl','rb')); gw=rates['gw']; sw=rates['sw']
Lnodes=gl[:,0]/1000.0   # MeV cm2/mg
def make_phi(col, table):
    """return fine grid L (MeV cm2/mg) and phi per (MeV cm2/mg) per cm2 per s, log-log interpolation"""
    Lnodes=table[:,0]/1000.0
    phi_nodes=table[:,col]*1000.0
    Lf=np.logspace(np.log10(Lnodes[0]),np.log10(min(Lnodes[-1],200.0)),20001)
    lp=np.full_like(Lnodes,-np.inf); pos=phi_nodes>0; lp[pos]=np.log(phi_nodes[pos])
    # interpolate log phi vs log L; where a node is zero, interpolate linearly to zero (treat as -inf -> 0)
    phi=np.zeros_like(Lf)
    li=np.log(Lnodes); lf=np.log(Lf)
    idx=np.searchsorted(li,lf,side='right')-1; idx=np.clip(idx,0,len(li)-2)
    for k in range(len(Lf)):
        i=idx[k]; a,b=phi_nodes[i],phi_nodes[i+1]
        t=(lf[k]-li[i])/(li[i+1]-li[i])
        if a>0 and b>0: phi[k]=np.exp(np.log(a)+t*(np.log(b)-np.log(a)))
        else: phi[k]=a*(1-t)+b*t   # linear if one end is zero
    return Lf,phi
def trapz(y,x): return np.trapezoid(y,x)
def rate_naive(Lf,phi,sigma):  # (7.1) with sigma_is = sigma_normal (7.12)
    return trapz(phi*sigma(Lf),Lf)
def rate_thin(Lf,phi,sigma,thmax_deg=60.0,nmu=400):  # (7.5)
    mu0=np.cos(np.radians(thmax_deg))
    mus=np.linspace(mu0,1.0,nmu)
    # inner integral: int_{mu0}^{1} sigma(L/mu) mu dmu
    inner=np.trapezoid(sigma(Lf[:,None]/mus[None,:])*mus[None,:],mus,axis=1)
    return trapz(phi*inner,Lf)
