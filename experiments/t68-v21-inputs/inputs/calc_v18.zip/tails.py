import pickle, numpy as np
runs=pickle.load(open('runs.pkl','rb'))
LET={'Ar1050MeV':5.2,'Ar548MeV':7.9,'U190.4GeV':15,'U142.8GeV':17,'U78.5GeV':22,'XeLET27':27,'U45.2GeV':29,'U35.7GeV':33,'XeLET42':42,'Xe2700MeV':44,'XeLET57':57}
print("Survival counts N(dy>=d) for d=0..20")
for k in sorted(LET,key=lambda s:LET[s]):
    dy=np.array([e['ys'].max()-e['ys'].min() for e in runs[k]])
    print(f"{k:10s} {LET[k]:4.0f} N={len(dy):5d} ", ' '.join(f"{int((dy>=d).sum()):4d}" for d in range(0,21)))
print("\nSurvival counts N(dx>=d) for d=0..16")
for k in sorted(LET,key=lambda s:LET[s]):
    dx=np.array([e['xs'].max()-e['xs'].min() for e in runs[k]])
    print(f"{k:10s} {LET[k]:4.0f} N={len(dx):5d} ", ' '.join(f"{int((dx>=d).sum()):4d}" for d in range(0,17)))
