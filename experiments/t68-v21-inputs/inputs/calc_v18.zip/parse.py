import re, os, glob, pickle, collections
D="data/New Folder"
def parse(path):
    clusters=[]; cur=None
    with open(path,encoding='latin-1') as f:
        for line in f:
            s=line.strip()
            if not s: continue
            if s.startswith('cluster'):
                cid=int(s.split()[1]); cur={'id':cid,'cells':[],'addr':[]}; continue
            if s.startswith('xadd'):
                continue
            if s.startswith('NUMBER OF EVENTS'):
                cur['n_decl']=int(s.split('=')[1]); clusters.append(cur); cur=None; continue
            p=s.split()
            if len(p)==2: cur['cells'].append((int(p[0]),int(p[1]))); cur['addr'].append(None)
            elif len(p)==3: cur['cells'].append((int(p[1]),int(p[2]))); cur['addr'].append(int(p[0]))
            else: raise ValueError((path,s))
    return clusters
data={}
for path in sorted(glob.glob(D+"/*.txt")):
    name=os.path.basename(path)[6:-4]
    data[name]=parse(path)
pickle.dump(data,open('data.pkl','wb'))
tot_ev=tot_cells=0
for k,cl in data.items():
    serv=[c for c in cl if set(c['cells'])=={(0,0)}]
    real=[c for c in cl if set(c['cells'])!={(0,0)}]
    dup=sum(len(c['cells'])-len(set(c['cells'])) for c in real)
    ncell=sum(len(set(c['cells'])) for c in real)
    decl_mismatch=sum(1 for c in real if c['n_decl']!=len(c['cells']))
    zero_in=sum(1 for c in real if (0,0) in c['cells'])
    tot_ev+=len(real); tot_cells+=ncell
    print(f"{k:12s} clusters={len(cl):6d} service={len(serv)} events={len(real):6d} uniq_cells={ncell:6d} dup_cells={dup:4d} decl!=lines={decl_mismatch} has(0,0)={zero_in}")
print("TOTAL events",tot_ev,"cells",tot_cells)
