import pickle, numpy as np, itertools, collections
from mapping_lib import addr_vec
data=pickle.load(open('data.pkl','rb'))
admissible=[(0,1),(0,2),(0,3),(0,5),(0,8),(0,10),(0,11),(0,12),(0,13),(0,15),(1,2),(1,3),(1,5),(1,8),(1,10),(1,11),(1,12),(1,13),(1,15),
 (2,3),(2,5),(2,8),(2,10),(2,11),(2,12),(2,13),(2,15),(3,5),(3,8),(3,10),(3,11),(3,12),(3,13),(3,15),(5,8),(5,10),(5,11),(5,12),(5,13),(5,15),
 (8,10),(8,11),(8,12),(8,13),(8,15),(10,11),(10,12),(10,13),(10,15),(11,12),(11,13),(11,15),(12,13),(12,15),(13,15)]
assert len(admissible)==55
allpairs=list(itertools.combinations(range(21),2))
runs={}
for k,cl in data.items():
    evs=[]
    for c in cl:
        cells=sorted(set(c['cells']))
        if cells==[(0,0)]: continue
        xs=np.array([p[0] for p in cells]); ys=np.array([p[1] for p in cells])
        a=addr_vec(xs,ys)
        D=set()
        m=len(cells)
        if m>1:
            A=a[:,None]^a[None,:]
            iu=np.triu_indices(m,1)
            d=A[iu]
            # keep XOR patterns with popcount<=2
            pc=np.array([bin(int(v)).count('1') for v in d])
            for v,p,i1,i2 in zip(d[pc<=2],pc[pc<=2],iu[0][pc<=2],iu[1][pc<=2]):
                D.add((int(v),))
        evs.append({'m':m,'D':D,'xs':xs,'ys':ys,'a':a})
    runs[k]=evs
pickle.dump(runs,open('runs.pkl','wb'))
def n1(evs,mask):
    cnt=0; cells=0
    for e in evs:
        if any((d[0] & ~mask)==0 for d in e['D']): cnt+=1; cells+=e['m']
    return cnt,cells
res={}
for k,evs in runs.items():
    res[k]={}
    for (i,j) in allpairs:
        mask=(1<<i)|(1<<j)
        res[k][(i,j)]=n1(evs,mask)
pickle.dump(res,open('n1.pkl','wb'))
# summary
order=['C360MeV','C720MeV','C1080MeV','Ar1050MeV','Ar548MeV','U190.4GeV','U142.8GeV','U78.5GeV','XeLET27','U45.2GeV','U35.7GeV','XeLET42','Xe2700MeV','XeLET57']
prot=[k for k in runs if k.startswith('p')]
print("run        N     S   N1(main A0,A1)  groupings(adm) with N1>0: counts")
for k in order+sorted(prot,key=lambda s: float(s[1:-3])):
    evs=runs[k]; N=len(evs); S=sum(e['m'] for e in evs)
    nz={p:res[k][p][0] for p in admissible if res[k][p][0]>0}
    nz_all={p:res[k][p][0] for p in allpairs if res[k][p][0]>0}
    print(f"{k:10s} {N:6d} {S:6d}  main={res[k][(0,1)][0]}  adm_nonzero={len(nz)} {dict(list(nz.items())[:12])}  | any-of-210 nonzero: {len(nz_all)}")
# totals over HI runs of the article (9) and all HI
art=['Ar1050MeV','U190.4GeV','U142.8GeV','U78.5GeV','XeLET27','U45.2GeV','U35.7GeV','XeLET42','XeLET57']
for name,sel in [('article 9 HI',art),('all 14 HI',order),('all protons',prot)]:
    tot=collections.Counter()
    for k in sel:
        for p in admissible: tot[p]+=res[k][p][0]
    dist=collections.Counter(tot[p] for p in admissible)
    print(name,"-> distribution of N1 over 55 admissible groupings:",dict(sorted(dist.items())))
    print("   groupings with >0:",{p:tot[p] for p in admissible if tot[p]>0})
