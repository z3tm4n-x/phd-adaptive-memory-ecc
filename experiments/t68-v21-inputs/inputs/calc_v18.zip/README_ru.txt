Воспроизводимость расчётов к статье (черновик v16)

Структура:
  data/New Folder/  — набор данных Zenodo 10.5281/zenodo.8314389 (28 файлов clust_*.txt)
  res/results/      — выгрузки COSRAD (ГКЛ: g*, СКЛ: s*)
Порядок запуска (Python 3, numpy, scipy, matplotlib):
  python3 parse.py            # чтение кластеров -> data.pkl (173 802 события, 299 026 ячеек)
  python3 validate_map.py     # проверка аффинного отображения (148 731 запись, 0 расхождений)
  python3 first_type.py       # события первого типа для всех 210 группировок -> runs.pkl, n1.pkl
  python3 geom.py; python3 tails.py   # геометрия кластеров
  python3 norm.py             # две нормировки флюенса, оценки и верхние границы sigma1 -> tab.pkl
  python3 cosrad.py; python3 check_cosrad.py   # разбор спектров COSRAD и проверка его частот
  python3 orbital.py          # воспроизведение табл. 2 исходной статьи (k*, tau_max)
  python3 sep.py; python3 geo.py; python3 tau.py; python3 req.py; python3 protons.py   # ГСО с ГКЛ и СКЛ
  python3 clump.py            # коэффициент R
  python3 figs.py             # рисунки 2, 4, 5 (новые)
Сводные таблицы: runs_summary.csv, first_type_by_grouping.csv, geo_results.csv

Дополнительно для v17:
  python3 pileup.py; python3 gapstats.py   # пары кластеров с промежутком 4–7 шагов против случайного расположения
  python3 merged.py           # подсчёт SMU после объединения кластеров с промежутком 4–5 шагов
  python3 v17calc.py          # все числа v17 -> v17.json
  python3 figs17.py           # рисунки 2–4 v17

Для v18:
  python3 thin.py             # расчёт для защиты 0,1–1,25 г/см² (архив results2 распаковать в res2/)
  python3 v18calc.py          # все числа v18 -> v18.json (38 разрядов, T_эф = 1,34 сут, смешанный член, огибающие SMU)
  python3 figs18.py           # рисунки 2–4 v18
