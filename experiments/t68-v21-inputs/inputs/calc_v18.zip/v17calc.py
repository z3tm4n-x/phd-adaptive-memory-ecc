import numpy as np, math, pickle, json
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
exec(open('sep.py').read().split("print(\"SEP proton spectrum")[0].split("exec(open('orbital.py')")[1].split("\n",1)[1])
Q=1e-3; T=10*365.25*86400; Teff=8e4; beta=31/(2*2**24)
F42,F44,F57,F2733,Fge27=9355.0,8825.0,8975.0,23179.0,50333.0
n4244,n57=2,4
s43=n4244/(F42+F44); s57=n57/F57
tH={1:3.3,2:2.7,3:2.4,4:2.2,5:2.1,6:2.0}
ub2733=3.0/(0.9*F2733); ub4244=tH[n4244]*(0.67+n4244)/(0.9*(F42+F44)); ub57=tH[n57]*(0.67+n57)/(0.9*F57); ubrow=3.0/(0.9*Fge27)
def s_pt(L): L=np.asarray(L,float); return np.where(L<=33,0.0,np.interp(L,[33,43,57],[0.0,s43,s57]))
def s_env(L): L=np.asarray(L,float); return np.where(L>=57,ub57,np.where(L>=43,ub4244,np.where(L>=27,ub2733,0.0)))
def s_row(L): return np.where(np.asarray(L)>=27,ubrow,0.0)
seg=lambda a,b: (lambda L: ((np.asarray(L)>=a)&(np.asarray(L)<b)).astype(float))
out=dict(s43=s43,s57=s57,ub2733=ub2733,ub4244=ub4244,ub57=ub57,ubrow=ubrow,rows=[])
for i,rho in enumerate(shield):
    col=i+1
    Lf,phi=make_phi(col,gl); Lfs,phis=make_phi(col,sl); phis=np.where(Lfs<=31.7,phis,0.0)
    nuG=rate_naive(Lf,phi,sig_nak)+rate_pl(col,gp,sig_p_710)*Nbits
    nuS=rate_naive(Lfs,phis,sig_nak)+rate_pl(col,sp,sig_p_710)*Nbits
    nuSp=rate_naive(Lfs,phis,sig_nak)+rate_pl(col,sp,sig_p_pdi)*Nbits
    L1pt=T*rate_naive(Lf,phi,s_pt)
    L1ptThin=T*rate_thin(Lf,phi,s_pt,60,200)+Teff*rate_thin(Lfs,phis,s_pt,60,200)
    L1envG=T*rate_naive(Lf,phi,s_env); L1envS=Teff*rate_naive(Lfs,phis,s_env)
    L1rowG=T*rate_naive(Lf,phi,s_row); L1rowS=Teff*rate_naive(Lfs,phis,s_row)
    P1=1-math.exp(-L1pt)
    tG=(Q-P1)/(beta*T*nuG**2); tS=(Q-P1)/(beta*(T*nuG**2+Teff*nuS**2)); tSp=(Q-P1)/(beta*(T*nuG**2+Teff*nuSp**2))
    kstar=-math.log(1-Q)/L1pt
    # required zero-event fluence (rows class) and (A0 class, 27-43 segment) for Lambda1<=5e-4
    E2743=T*rate_naive(Lf,phi,seg(27,43))+Teff*rate_naive(Lfs,phis,seg(27,43))
    rest=ub4244*(T*rate_naive(Lf,phi,seg(43,57)))+ub57*(T*rate_naive(Lf,phi,seg(57,200)))
    reqA0=3.0/(0.9*((5e-4-rest)/E2743)) if rest<5e-4 else float('inf')
    Eall=T*rate_naive(Lf,phi,seg(27,200))+Teff*rate_naive(Lfs,phis,seg(27,200))
    reqRow=3.0/(0.9*(5e-4/Eall))
    out['rows'].append(dict(rho=float(rho),nuG=nuG,nuS=nuS,nuSp=nuSp,L1pt=L1pt,kstar=kstar,L1ptThin=L1ptThin,L1env=L1envG+L1envS,L1envS=L1envS,L1row=L1rowG+L1rowS,L1rowS=L1rowS,tG=tG,tS=tS,tSp=tSp,reqA0=reqA0,reqRow=reqRow))
json.dump(out,open('v17.json','w'),indent=1)
print(f"s43={s43:.3e} s57={s57:.3e} UB: 27-33 {ub2733:.3e} 42-44 {ub4244:.3e} 57 {ub57:.3e} row {ubrow:.3e}")
for r in out['rows']:
    print(f"{r['rho']:4.2f} nuG={r['nuG']:.3e} nuS={r['nuS']:.3f} nuSp={r['nuSp']:.3f} | L1pt={r['L1pt']:.2e} k*={r['kstar']:.0f} thin={r['L1ptThin']:.2e} | env={r['L1env']:.2e} (S {r['L1envS']/r['L1env']:.0%}) row={r['L1row']:.2e} | tG={r['tG']:.0f} tS={r['tS']:.3f} tSp={r['tSp']:.4f} | reqA0={r['reqA0']:.2e} reqRow={r['reqRow']:.2e}")
