import numpy as np, math
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
# PDI curve (Cypress 65 nm, CNA, normal incidence) digitized from REDW-2020 Fig.6 / TNS-2021 Fig.3
Epdi=np.array([0.6,0.7,0.8,0.9,1.0,1.1,1.5,2.0,2.5,3.0,4.0,5.0])
Spdi=np.array([4.1e-11,1.36e-10,1.06e-9,9.4e-10,1.30e-9,4.1e-10,5.65e-11,4.7e-12,1.6e-12,6.1e-13,1.47e-13,6.7e-14])
def sig_p_pdi(E):
    E=np.asarray(E,float)
    s=np.exp(np.interp(E,Epdi,np.log(Spdi),left=-np.inf,right=np.log(Spdi[-1])))
    s=np.where(E<Epdi[0],0.0,s)
    # above 5 MeV: connect to HEP curve (take max of PDI tail and HEP)
    return np.maximum(np.where(E<=5.0,s,0.0), sig_p_710(E))
def rate_pl(col,table,sig,factor=0.5):
    E=table[:,0]; f=table[:,col]
    Ef=np.logspace(np.log10(E[0]),np.log10(E[-1]),40001)
    lf=np.log(np.where(f>0,f,1e-300)); ff=np.exp(np.interp(np.log(Ef),np.log(E),lf)); ff[ff<1e-290]=0
    return factor*np.trapezoid(sig(Ef)*ff,Ef)
print("SEP proton spectrum behind shielding at low energy (col 1.5 g/cm2):")
for e,f in zip(sp[:,0],sp[:,1]):
    if 0.4<=e<=12: print(f"  E={e:6.3f} MeV  f={f:.3e} /(MeV cm2 s)")
print()
print("rho | GCR: nu_ion  nu_p | SEP peak: nu_ion(naive) nu_ion(thin60) nu_p_HEP  nu_p_PDI(+HEP) | ratio SEP/GCR (ions naive)")
res=[]
for i,rho in enumerate(shield):
    Lf,phi=make_phi(i+1,gl); gion=rate_naive(Lf,phi,sig_nak); gp_=rate_pl(i+1,gp,sig_p_710)*Nbits
    Lfs,phis=make_phi(i+1,sl)
    sion=rate_naive(Lfs,phis,sig_nak); sion_t=rate_thin(Lfs,phis,sig_nak,60,200)
    sp_h=rate_pl(i+1,sp,sig_p_710)*Nbits; sp_pdi=rate_pl(i+1,sp,sig_p_pdi)*Nbits
    res.append((rho,gion,gp_,sion,sion_t,sp_h,sp_pdi))
    print(f"{rho:4.2f} | {gion:9.3e} {gp_:9.3e} | {sion:11.3e} {sion_t:11.3e} {sp_h:10.3e} {sp_pdi:12.3e} | {sion/gion:8.0f}")
np.save('sep_rates.npy',np.array(res))
