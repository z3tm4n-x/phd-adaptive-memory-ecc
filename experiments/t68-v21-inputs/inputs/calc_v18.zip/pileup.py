import pickle, numpy as np
from collections import defaultdict
runs=pickle.load(open('runs.pkl','rb'))
rng=np.random.default_rng(3)
def min_l1(A,B):
    d=np.abs(A[:,None,:]-B[None,:,:]).sum(-1); return int(d.min())
def near_pairs(evs,maxd=7,cell=32):
    boxes=[(e['xs'].min(),e['xs'].max(),e['ys'].min(),e['ys'].max()) for e in evs]
    grid=defaultdict(list)
    for i,(x0,x1,y0,y1) in enumerate(boxes):
        for gx in range(x0//cell,x1//cell+1):
            for gy in range(y0//cell,y1//cell+1): grid[(gx,gy)].append(i)
    cand=set()
    for i,(x0,x1,y0,y1) in enumerate(boxes):
        for gx in range((x0-maxd)//cell,(x1+maxd)//cell+1):
            for gy in range((y0-maxd)//cell,(y1+maxd)//cell+1):
                for j in grid.get((gx,gy),[]):
                    if j>i: cand.add((i,j))
    hist=defaultdict(int)
    for i,j in cand:
        bi,bj=boxes[i],boxes[j]
        gapx=max(0,bj[0]-bi[1],bi[0]-bj[1]); gapy=max(0,bj[2]-bi[3],bi[2]-bj[3])
        if gapx+gapy>maxd: continue
        A=np.stack([evs[i]['xs'],evs[i]['ys']],1); B=np.stack([evs[j]['xs'],evs[j]['ys']],1)
        d=min_l1(A,B)
        if d<=maxd: hist[d]+=1
    return dict(sorted(hist.items()))
def merge_area(evs,n=2000,r=3):
    # expected number of relative placements with min L1 distance <= r, and 4..7 (annulus), per random pair
    tot_le=0; tot_an=0
    for _ in range(n):
        i,j=rng.integers(0,len(evs),2)
        A=np.stack([evs[i]['xs'],evs[i]['ys']],1); B=np.stack([evs[j]['xs'],evs[j]['ys']],1)
        D=(A[:,None,:]-B[None,:,:]).reshape(-1,2)
        # set of translations t with min_{a,b} |a-(b+t)|_1 <= R  -> dilate difference set by L1 ball
        s=set(map(tuple,D))
        def dil(R):
            out=set()
            for (dx,dy) in s:
                for ax in range(-R,R+1):
                    rem=R-abs(ax)
                    for ay in range(-rem,rem+1): out.add((dx+ax,dy+ay))
            return out
        a3=len(dil(r)); a7=len(dil(7))
        tot_le+=a3; tot_an+=(a7-a3)
    return tot_le/n, tot_an/n
Ncells=2**24
for run in ['U45.2GeV','XeLET27','XeLET42','Xe2700MeV','XeLET57']:
    evs=runs[run]; N=len(evs)
    h=near_pairs(evs)
    a3,a47=merge_area(evs,600)
    pairs=N*(N-1)/2
    exp_le3_allsim=pairs*a3/Ncells; exp_4_7_allsim=pairs*a47/Ncells
    obs47=sum(v for d,v in h.items() if 4<=d<=7)
    print(f"{run:10s} N={N}  observed pairs by min L1 gap (not merged, >3): {h}  | obs 4..7: {obs47}")
    print(f"           random placement, all clusters simultaneous: expected gap<=3 (would merge): {exp_le3_allsim:.1f}, gap 4..7: {exp_4_7_allsim:.1f}")
    print(f"           => ratio merges/near-misses = {a3/a47:.2f};  implied merges ~ observed near-misses x ratio = {obs47*a3/a47:.1f}")
