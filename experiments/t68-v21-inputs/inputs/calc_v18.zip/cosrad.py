import numpy as np, re, glob, os
R='res/results/'
def read_table(fn, ncol=10):
    rows=[]
    for line in open(R+fn,encoding='latin-1'):
        p=line.split()
        if len(p)==ncol:
            try: rows.append([float(v) for v in p])
            except: pass
    return np.array(rows)
shield=np.array([1.5,1.75,2.0,2.25,2.5,2.75,3.0,3.5,4.0])
gl=read_table('gl_x.txt'); sl=read_table('sl_x.txt'); gp=read_table('gp_x.txt'); sp=read_table('sp_x.txt')
def read_rates(prefix):
    out={}
    for fn in sorted(glob.glob(R+prefix+'_x_*.txt')):
        txt=open(fn,encoding='latin-1').read()
        th=os.path.basename(fn).split('_x_')[1][:-4]
        th=float(th.replace('015','0.15').replace('05','0.5')) if th in ('015','05') else float(th)
        rows=[]
        for line in txt.splitlines():
            p=line.split()
            if len(p)==4:
                try: rows.append([float(v) for v in p])
                except: pass
        out[th]=np.array(rows)
    return out
gw=read_rates('gw'); sw=read_rates('sw')
np.savez('cosrad.npz',gl=gl,sl=sl,gp=gp,sp=sp,shield=shield)
import pickle; pickle.dump({'gw':gw,'sw':sw},open('cosrad_rates.pkl','wb'))
print("GCR LET grid (MeV cm2/mg):", gl[:,0][:5]/1000, '...', gl[:,0][-5:]/1000, " n=",len(gl))
print("thresholds:",sorted(gw.keys()))
# high-LET tail of GCR and SEP spectra at 1.5 g/cm2
for L,g,s in zip(gl[:,0]/1000,gl[:,1],sl[:,1]):
    if L>=10: print(f"L={L:7.2f}  GCR phi={g:.3e}  SEP phi={s:.3e}")
