import numpy as np, math
exec(open('spectra_lib.py').read())
Nbits=2**24; n=32; beta=(n-1)/(2*Nbits); Q=1e-3; T=10*365.25*86400
ssat,L0w,W,h=2.6e-7,0.15,70.0,1.2
def sb(L):
    L=np.asarray(L,dtype=float); x=np.clip((L-L0w)/W,0,None)
    return np.where(L>L0w, ssat*(1-np.exp(-x**h)), 0.0)
LETpts=np.array([5.2,15,17,22,27,29,33,42,57])
frac=np.array([1,1,1,1,1,1,1,16969/17012,21058/21185])
def fr(L): return np.interp(L,LETpts,frac)   # constant outside
def sig_nak(L): return Nbits*sb(L)*fr(L)
def sig1_point(L):
    L=np.asarray(L,dtype=float)
    return np.where(L<33,0.0, np.interp(L,[33,42,57],[0.0,1.069e-4,3.343e-4]))
def sig1_step(L,Lstar=33,h1=1.0896e-3):
    return np.where(np.asarray(L)>=Lstar,h1,0.0)
# protons: GCR proton spectrum behind shielding (per MeV per cm2 per s), energy grid
Ep=gp[:,0]
def sig_p_step(E): return np.where(E>=10,8e-14,0.0)
def sig_p_710(E,E0=10.0,sm=8e-14):
    E=np.asarray(E,float); x=np.clip(E-E0,0,None)
    return np.where(E>E0, sm*(1-np.exp(-0.18*np.sqrt(np.sqrt(18/E0)*x)))**4, 0.0)
def proton_rate(col,table,sig):
    E=table[:,0]; f=table[:,col]
    # log-log interpolation on fine grid
    Ef=np.logspace(np.log10(E[0]),np.log10(E[-1]),20001)
    ff=np.interp(np.log(Ef),np.log(E),np.log(np.where(f>0,f,1e-300))); ff=np.exp(ff); ff[ff<1e-290]=0
    return 0.5*np.trapezoid(sig(Ef)*ff,Ef)
print("rho  nu_nak_ion   nu_nak_p(step)  nu_nak_p(7.10)  nu1_point   k*    tau_max   | nu1_step  ratio  f1(k~28)")
out=[]
for i,rho in enumerate(shield):
    Lf,phi=make_phi(i+1,gl)
    nni=rate_naive(Lf,phi,sig_nak)
    npst=proton_rate(i+1,gp,sig_p_step)*Nbits
    np710=proton_rate(i+1,gp,sig_p_710)*Nbits
    nn=nni+np710
    n1=rate_naive(Lf,phi,sig1_point)
    n1s=rate_naive(Lf,phi,sig1_step)
    kstar=-math.log(1-Q)/(T*n1)
    f10=(1-math.exp(-T*n1))/Q
    tau=(Q-(1-math.exp(-T*n1)))/(T*beta*nn**2)
    out.append((rho,nni,npst,np710,n1,kstar,tau,n1s,n1s/n1))
    print(f"{rho:4.2f} {nni:10.3e} {npst:13.3e} {np710:13.3e} {n1:11.3e} {kstar:6.1f} {tau:8.1f}   | {n1s:9.3e} {n1s/n1:6.1f}")
