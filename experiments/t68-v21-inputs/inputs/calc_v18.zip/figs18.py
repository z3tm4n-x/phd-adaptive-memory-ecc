import numpy as np, pickle, json
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.grid':True,'grid.alpha':0.3})
comma=FuncFormatter(lambda v,p: (f"{v:g}").replace('.',','))
V18=json.load(open('v18.json')); R=V18['rows']
# ---------- Fig 2 (bigger fonts) ----------
s=open('figs17.py').read().split("# ---------- Fig 3")[0]
s=s.replace("plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.grid':True,'grid.alpha':0.3})","plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.grid':True,'grid.alpha':0.3})")
s=s.replace("fig=plt.figure(figsize=(11,4.2))","fig=plt.figure(figsize=(12,4.8))").replace("fontsize=7,title_fontsize=7","fontsize=9,title_fontsize=9").replace("fig/v17_fig2.png","fig/v18_fig2.png")
exec(s)
# ---------- Fig 3: tau vs shielding 0.1..4 ----------
rho=np.array([r['rho'] for r in R]); tG=np.array([r['tG'] for r in R]); tU=np.array([r['tU'] for r in R]); tP=np.array([r['tP'] for r in R])
fig,ax=plt.subplots(figsize=(7,4.6))
ax.semilogy(rho,tG,'ko-',ms=4,label='только ГКЛ')
ax.semilogy(rho,tU,'bs-',ms=4,label='ГКЛ + СКЛ')
ax.semilogy(rho,tP,'r^--',ms=4,label='ГКЛ + СКЛ с прямой ионизацией протонами')
styles=[(0.189,(0,(1,1)),'чтение и запись всех 2²¹ адресов'),(0.094,(0,(4,2)),'чтение всех 2²¹ адресов, запись по ERR'),(0.047,(0,(6,2,1,2)),'чтение и запись 2¹⁹ слов'),(0.024,(0,(1,3)),'чтение 2¹⁹ слов, запись по ERR')]
for y,ls,lab in styles:
    ax.axhline(y,color='dimgray',ls=ls,lw=1.2,label=lab)
ax.set_xlabel('Поверхностная плотность алюминиевой защиты, г/см²'); ax.set_ylabel('Допустимый период скраббинга, с')
ax.xaxis.set_major_formatter(comma); ax.set_xlim(0,4.1); ax.set_ylim(1e-6,1e3)
ax.legend(fontsize=8,loc='lower right',ncol=1,framealpha=0.95)
plt.tight_layout(); plt.savefig('fig/v18_fig3.png',dpi=200); plt.close()
# ---------- Fig 4: spectra + sigma1 envelopes ----------
exec(open('orbital.py').read().split("print(\"rho  nu_nak_ion")[0])
T=10*365.25*86400; Teff=1.34*86400; col=5
Lf,phi=make_phi(col,gl); Lfs,phis=make_phi(col,sl); phis=np.where(Lfs<=31.7,phis,0.0)
def integ(Lf,phi):
    c=np.concatenate([[0],np.cumsum(0.5*(phi[1:]+phi[:-1])*np.diff(Lf))]); return c[-1]-c
IG=integ(Lf,phi)*T; IS=integ(Lfs,phis)*Teff
fig,axs=plt.subplots(2,1,figsize=(7,8))
ax=axs[0]; ax.loglog(Lf,IG,'k-',label='ГКЛ, 10 лет'); m=IS>0; ax.loglog(Lfs[m],IS[m],'b--',label='СКЛ, $T_{эф}$ = 1,34 сут')
ax.set_ylabel('Флюенс частиц с ЛПЭ > L, см⁻²'); ax.set_ylim(1e-3,1e8); ax.axvspan(27,33,color='orange',alpha=0.25,label='ЛПЭ 27–33 МэВ·см²/мг')
ax.legend(fontsize=9,loc='lower left'); ax.set_title('а',loc='left'); ax.set_xlim(0.1,120); ax.xaxis.set_major_formatter(comma); ax.set_xlabel('ЛПЭ, МэВ·см²/мг')
ax=axs[1]
Ls=[27,29,33,42,44,57]
def steps(b):
    xs=[27]; ys=[b['27']]
    prev=27
    for Li in Ls:
        xs+= [prev,Li]; ys+=[b[str(Li)],b[str(Li)]]; prev=Li
    return xs[1:],ys[1:]
for key,col_,lab in (('bA0','r','верхняя расчётная оценка, слово в разных строках'),('bRow','g','верхняя расчётная оценка, слово в одной строке')):
    b=V18[key]; x,y=steps(b)
    ax.plot(x,y,color=col_,lw=1.8,label=lab)
    ax.plot([57,100],[b['57'],b['57']],color=col_,lw=1.8,ls='--')
ax.plot([43,57],[1/18180.0*2,4/8975.0],'ko',ms=6,label='точечные оценки по данным (слово в разных строках)')
ax.axvline(27,color='gray',ls=':',lw=1)
ax.text(27.6,2.2e-5,'ниже 27 — SMU\nне учитываются\n(допущение)',fontsize=8,color='dimgray')
ax.text(60,2.6e-3,'выше 57 — продолжение\n(допущение)',fontsize=8,color='dimgray')
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('ЛПЭ, МэВ·см²/мг'); ax.set_ylabel('Сечение SMU, см²'); ax.set_ylim(1e-6,1e-2)
ax.legend(fontsize=8,loc='lower right'); ax.set_title('б',loc='left')
ax.set_xlim(20,100); ax.set_xticks([20,30,40,50,60,80,100]); ax.xaxis.set_major_formatter(comma); ax.xaxis.set_minor_formatter(FuncFormatter(lambda v,p:''))
plt.tight_layout(); plt.savefig('fig/v18_fig4.png',dpi=200); plt.close()
print('ok')
