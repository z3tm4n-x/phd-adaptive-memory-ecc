import numpy as np
from spectra_lib import *
step=lambda Lth: (lambda L: (np.asarray(L)>=Lth).astype(float))
print("GCR, shield 1.5 g/cm2 (col 1): COSRAD ion rate vs my integrals for a 1 cm2 step")
Lf,phi=make_phi(1,gl)
print(" Lth    COSRAD      naive(7.12)   thin60(7.5)  thin90   COS/naive  COS/thin60")
for Lth in sorted(gw):
    cos=gw[Lth][0,2]
    s=step(Lth)
    rn=rate_naive(Lf,phi,s); r60=rate_thin(Lf,phi,s,60,300); r90=rate_thin(Lf,phi,s,89.9,300)
    print(f"{Lth:5.2f} {cos:10.3e} {rn:12.3e} {r60:12.3e} {r90:10.3e}   {cos/rn:8.3f}  {cos/r60:8.3f}")
print("\nSEP peak, shield 1.5:")
Lf,phi=make_phi(1,sl)
for Lth in sorted(sw):
    cos=sw[Lth][0,2]; s=step(Lth)
    rn=rate_naive(Lf,phi,s); r60=rate_thin(Lf,phi,s,60,300)
    print(f"{Lth:5.2f} {cos:10.3e} {rn:12.3e} {r60:12.3e}   {cos/rn if rn>0 else float('nan'):8.3f}  {cos/r60 if r60>0 else float('nan'):8.3f}")
